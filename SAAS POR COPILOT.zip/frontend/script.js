// Lead filtering (IA)
document.getElementById("leadForm").onsubmit = async e => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target));
    const res = await fetch("/leads/event", { method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify({
        event_type: "filter_lead", payload: data
    })});
    document.getElementById("leadResult").textContent = (await res.json()).result || "Error";
};
// WhatsApp message
document.getElementById("waMsgForm").onsubmit = async e => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target));
    const res = await fetch("/whatsapp/send", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(data)});
    document.getElementById("waResult").textContent = (await res.json()).success ? "Mensaje enviado" : "Error";
};
// WhatsApp PDF
document.getElementById("waPdfForm").onsubmit = async e => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target));
    const res = await fetch("/whatsapp/send-pdf", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(data)});
    document.getElementById("waResult").textContent = (await res.json()).success ? "PDF enviado" : "Error";
};
// WhatsApp Cita
document.getElementById("waCitaForm").onsubmit = async e => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target));
    const res = await fetch("/whatsapp/schedule", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(data)});
    document.getElementById("waResult").textContent = (await res.json()).success ? "Cita agendada" : "Error";
};
// Leads List
async function fetchLeads() {
    const res = await fetch("/leads/");
    const leads = await res.json();
    const ul = document.getElementById("leadsList");
    ul.innerHTML = "";
    leads.forEach(l => { ul.innerHTML += `<li>${l.name} (${l.profile})</li>` });
}