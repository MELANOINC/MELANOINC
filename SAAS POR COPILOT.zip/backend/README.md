# LeadBot-Pro MELANO INC

**Stack:** FastAPI + PostgreSQL + OpenAI + Twilio (WhatsApp)  
**Incluye:**  
- Filtrado IA de leads por perfil
- Backend SQL ligero y escalable
- WhatsApp automatizado (PDF, mensajes, citas)
- Tests
- Frontend funcional
- Dockerfile y docker-compose listos para deploy

## Instalación

1. Clona el repo y entra en la carpeta raíz.
2. Crea un virtualenv:
   ```
   python3 -m venv venv
   source venv/bin/activate
   ```
3. Instala dependencias:
   ```
   pip install -r backend/requirements.txt
   ```
4. Copia `.env.example` a `.env` y completa tus claves.
5. Inicializa la base de datos:
   ```
   docker-compose run backend python -c "from app.services.db import Base, engine; Base.metadata.create_all(bind=engine)"
   ```
6. Ejecuta el server:
   ```
   docker-compose up --build
   ```

## Deploy en Railway o VPS

- Railway: Sube el repo, configura variables de entorno desde `.env.example`, deploy automático por Dockerfile.
- VPS: Clona el repo, edita `.env`, `docker-compose up --build`

## Tests

```
docker-compose run backend pytest
```