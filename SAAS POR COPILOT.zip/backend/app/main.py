from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
import os

from app.api import leads, whatsapp

load_dotenv()

app = FastAPI(title="LeadBot-Pro MELANO INC")

app.include_router(leads.router, prefix="/leads", tags=["Leads"])
app.include_router(whatsapp.router, prefix="/whatsapp", tags=["WhatsApp"])

# Permitir requests desde cualquier origen (para desarrollo)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def read_root():
    return {"message": "Leadbot-Pro Backend activo"}