from pydantic import BaseModel
from sqlalchemy import Column, Integer, String, Text
from app.services.db import Base

class LeadORM(Base):
    __tablename__ = "leads"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    email = Column(String, nullable=False)
    profile = Column(String, nullable=False)
    notes = Column(Text)

class Lead(BaseModel):
    id: int = None
    name: str
    email: str
    profile: str
    notes: str = ""
    class Config:
        orm_mode = True