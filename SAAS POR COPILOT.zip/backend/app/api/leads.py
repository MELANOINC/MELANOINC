from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.core.events import handle_event
from app.models.lead import Lead, LeadORM
from app.services.db import SessionLocal, Base, engine
from pydantic import BaseModel

router = APIRouter()

class LeadEvent(BaseModel):
    event_type: str
    payload: dict

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/event")
def process_lead_event(event: LeadEvent):
    result = handle_event(event.event_type, event.payload)
    return {"result": result}

@router.post("/", response_model=Lead)
def create_lead(lead: Lead, db: Session = Depends(get_db)):
    db_lead = LeadORM(**lead.dict(exclude={"id"}))
    db.add(db_lead)
    db.commit()
    db.refresh(db_lead)
    return db_lead

@router.get("/", response_model=list[Lead])
def get_leads(db: Session = Depends(get_db)):
    return db.query(LeadORM).all()