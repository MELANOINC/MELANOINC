from fastapi import APIRouter
from pydantic import BaseModel
from app.services.whatsapp_service import send_whatsapp_message, send_pdf_via_whatsapp, schedule_appointment

router = APIRouter()

class WhatsAppMsg(BaseModel):
    number: str
    text: str

class WhatsAppPDF(BaseModel):
    number: str
    pdf_url: str

class WhatsAppAppointment(BaseModel):
    number: str
    datetime: str

@router.post("/send")
def send_message(data: WhatsAppMsg):
    result = send_whatsapp_message(data.number, data.text)
    return {"success": result}

@router.post("/send-pdf")
def send_pdf(data: WhatsAppPDF):
    result = send_pdf_via_whatsapp(data.number, data.pdf_url)
    return {"success": result}

@router.post("/schedule")
def schedule(data: WhatsAppAppointment):
    result = schedule_appointment(data.number, data.datetime)
    return {"success": result}