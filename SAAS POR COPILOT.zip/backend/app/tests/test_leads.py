from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_create_lead_event():
    response = client.post("/leads/event", json={
        "event_type": "filter_lead",
        "payload": {"name": "Juan", "email": "juan@mail.com", "profile": "inversión"}
    })
    assert response.status_code == 200
    assert "result" in response.json()