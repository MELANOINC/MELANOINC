from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_send_message(monkeypatch):
    monkeypatch.setattr("app.services.whatsapp_service.send_whatsapp_message", lambda n, t: True)
    response = client.post("/whatsapp/send", json={
        "number": "whatsapp:+54911xxxxxxx",
        "text": "¡Hola!"
    })
    assert response.status_code == 200
    assert response.json()["success"] is True