import os
from twilio.rest import Client

account_sid = os.getenv("TWILIO_ACCOUNT_SID")
auth_token = os.getenv("TWILIO_AUTH_TOKEN")
whatsapp_from = os.getenv("TWILIO_PHONE")
client = Client(account_sid, auth_token)

def send_whatsapp_message(number, text):
    try:
        client.messages.create(body=text, from_=whatsapp_from, to=number)
        return True
    except Exception as e:
        print(e)
        return False

def send_pdf_via_whatsapp(number, pdf_url):
    try:
        client.messages.create(body="Aquí tienes el PDF solicitado.", media_url=[pdf_url], from_=whatsapp_from, to=number)
        return True
    except Exception as e:
        print(e)
        return False

def schedule_appointment(number, datetime):
    text = f"Hola! Tu cita ha sido agendada para {datetime}. ¿Confirmás?"
    return send_whatsapp_message(number, text)