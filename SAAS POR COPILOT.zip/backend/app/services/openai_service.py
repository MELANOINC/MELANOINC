import openai
import os

openai.api_key = os.getenv("OPENAI_API_KEY")

def run_openai(prompt):
    resp = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "system", "content": prompt}],
        max_tokens=128
    )
    return resp.choices[0].message.content.strip()