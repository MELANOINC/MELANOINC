from app.services.openai_service import run_openai

def agent_filter_lead(lead_data):
    prompt = (
        f"Eres un bot que filtra leads para: {lead_data.get('profile','')}. "
        f"Evalúa este lead. Si encaja con el perfil, responde 'SI' y explica por qué. Si no, responde 'NO' y justifica."
        f"Lead: {lead_data}"
    )
    return run_openai(prompt)