from app.core.agents import agent_filter_lead

def handle_event(event_type, payload):
    if event_type == "filter_lead":
        return agent_filter_lead(payload)
    else:
        return {"error": "Tipo de evento desconocido"}