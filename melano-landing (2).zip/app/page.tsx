import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { ArrowRight, Shield, Car, Home, Heart, Users, Star, Phone, MessageCircle, Calculator } from "lucide-react"
import Link from "next/link"

export default function InsuranceLanding() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-indigo-900 to-blue-900">
      {/* Header */}
      <header className="border-b border-white/10 bg-black/20 backdrop-blur-md sticky top-0 z-50">
        <div className="container mx-auto px-4 lg:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-lg flex items-center justify-center">
              <Shield className="h-5 w-5 text-white" />
            </div>
            <span className="text-white font-bold text-xl">SEGUROS INTELIGENTES</span>
          </div>

          <nav className="hidden md:flex items-center space-x-8">
            <Link href="#cotizar" className="text-gray-300 hover:text-white transition-colors">
              Cotizar
            </Link>
            <Link href="#seguros" className="text-gray-300 hover:text-white transition-colors">
              Seguros
            </Link>
            <Link href="#beneficios" className="text-gray-300 hover:text-white transition-colors">
              Beneficios
            </Link>
            <Link href="#contacto" className="text-gray-300 hover:text-white transition-colors">
              Contacto
            </Link>
          </nav>

          <Button className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white">
            <MessageCircle className="h-4 w-4 mr-2" />
            Chat con ALEXIA
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 lg:py-32">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="text-center max-w-4xl mx-auto mb-16">
            <Badge className="mb-6 bg-blue-500/20 text-blue-300 border-blue-500/30">
              🛡️ Protección Inteligente 24/7
            </Badge>

            <h1 className="text-4xl lg:text-6xl font-bold text-white mb-6 leading-tight">
              Cotizá tu{" "}
              <span className="bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
                seguro ideal
              </span>{" "}
              en 2 minutos
            </h1>

            <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
              Comparamos las mejores opciones del mercado y te mostramos la cobertura perfecta para vos.
              <strong className="text-white"> Sin papeleos, sin esperas, sin complicaciones.</strong>
            </p>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
              <div className="text-center p-4 bg-white/5 rounded-lg border border-white/10">
                <Car className="h-8 w-8 text-blue-400 mx-auto mb-2" />
                <div className="text-white font-semibold">Auto</div>
                <div className="text-gray-400 text-sm">Desde $2.500/mes</div>
              </div>
              <div className="text-center p-4 bg-white/5 rounded-lg border border-white/10">
                <Home className="h-8 w-8 text-blue-400 mx-auto mb-2" />
                <div className="text-white font-semibold">Hogar</div>
                <div className="text-gray-400 text-sm">Desde $1.800/mes</div>
              </div>
              <div className="text-center p-4 bg-white/5 rounded-lg border border-white/10">
                <Heart className="h-8 w-8 text-blue-400 mx-auto mb-2" />
                <div className="text-white font-semibold">Salud</div>
                <div className="text-gray-400 text-sm">Desde $4.200/mes</div>
              </div>
              <div className="text-center p-4 bg-white/5 rounded-lg border border-white/10">
                <Users className="h-8 w-8 text-blue-400 mx-auto mb-2" />
                <div className="text-white font-semibold">Vida</div>
                <div className="text-gray-400 text-sm">Desde $890/mes</div>
              </div>
            </div>
          </div>

          {/* Cotizador Rápido */}
          <div className="max-w-2xl mx-auto">
            <Card className="bg-white/10 border-white/20 backdrop-blur-md">
              <CardHeader className="text-center">
                <CardTitle className="text-white text-2xl">🚀 Cotización Express</CardTitle>
                <CardDescription className="text-gray-300">
                  Completá estos datos y recibí tu cotización personalizada al instante
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="nombre" className="text-white">
                      Nombre completo
                    </Label>
                    <Input
                      id="nombre"
                      placeholder="Tu nombre"
                      className="bg-white/10 border-white/20 text-white placeholder:text-gray-400"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="telefono" className="text-white">
                      WhatsApp
                    </Label>
                    <Input
                      id="telefono"
                      placeholder="+54 9 11 1234-5678"
                      className="bg-white/10 border-white/20 text-white placeholder:text-gray-400"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email" className="text-white">
                    Email
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="tu@email.com"
                    className="bg-white/10 border-white/20 text-white placeholder:text-gray-400"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="seguro" className="text-white">
                    ¿Qué seguro necesitás?
                  </Label>
                  <Select>
                    <SelectTrigger className="bg-white/10 border-white/20 text-white">
                      <SelectValue placeholder="Seleccioná el tipo de seguro" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="auto">🚗 Seguro de Auto</SelectItem>
                      <SelectItem value="hogar">🏠 Seguro de Hogar</SelectItem>
                      <SelectItem value="salud">❤️ Seguro de Salud</SelectItem>
                      <SelectItem value="vida">👨‍👩‍👧‍👦 Seguro de Vida</SelectItem>
                      <SelectItem value="moto">🏍️ Seguro de Moto</SelectItem>
                      <SelectItem value="comercio">🏢 Seguro Comercial</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="comentarios" className="text-white">
                    Comentarios adicionales (opcional)
                  </Label>
                  <Textarea
                    id="comentarios"
                    placeholder="Contanos qué cobertura específica buscás o si tenés alguna duda..."
                    className="bg-white/10 border-white/20 text-white placeholder:text-gray-400"
                  />
                </div>

                <div className="flex flex-col sm:flex-row gap-4">
                  <Button
                    size="lg"
                    className="flex-1 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white"
                  >
                    <Calculator className="h-5 w-5 mr-2" />
                    Cotizar Ahora
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    className="flex-1 border-green-500/50 text-green-300 hover:bg-green-500/10"
                  >
                    <MessageCircle className="h-5 w-5 mr-2" />
                    Chat con ALEXIA
                  </Button>
                </div>

                <div className="text-center text-sm text-gray-400">
                  ✅ Sin compromiso • ✅ Respuesta inmediata • ✅ Asesoramiento gratuito
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Beneficios */}
      <section id="beneficios" className="py-20 bg-black/20">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">🎯 ¿Por qué elegirnos?</h2>
            <p className="text-xl text-gray-300">La forma más inteligente de proteger lo que más querés</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="bg-white/5 border-white/10">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Calculator className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-white font-semibold mb-2">Cotización Instantánea</h3>
                <p className="text-gray-400">
                  Comparamos 15+ aseguradoras en tiempo real y te mostramos las mejores opciones
                </p>
              </CardContent>
            </Card>

            <Card className="bg-white/5 border-white/10">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <MessageCircle className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-white font-semibold mb-2">Atención 24/7</h3>
                <p className="text-gray-400">
                  ALEXIA, nuestra IA especializada, te atiende cualquier día a cualquier hora
                </p>
              </CardContent>
            </Card>

            <Card className="bg-white/5 border-white/10">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-white font-semibold mb-2">Mejor Precio Garantizado</h3>
                <p className="text-gray-400">
                  Si encontrás una cotización mejor, te igualamos el precio + 5% de descuento
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Testimonios */}
      <section className="py-20">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">Lo que dicen nuestros clientes</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="bg-white/5 border-white/10">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-300 mb-4">
                  "En 3 minutos tenía mi seguro de auto contratado. ALEXIA me explicó todo súper claro y conseguí 30%
                  menos que mi seguro anterior."
                </p>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center mr-3">
                    <span className="text-white font-bold text-sm">MR</span>
                  </div>
                  <div>
                    <div className="text-white font-semibold">María Rodríguez</div>
                    <div className="text-gray-400 text-sm">Seguro de Auto</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/5 border-white/10">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-300 mb-4">
                  "Increíble el servicio. Contraté seguro de hogar y vida en la misma conversación. Todo digital, sin
                  papeleos."
                </p>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center mr-3">
                    <span className="text-white font-bold text-sm">JL</span>
                  </div>
                  <div>
                    <div className="text-white font-semibold">Juan López</div>
                    <div className="text-gray-400 text-sm">Seguro Hogar + Vida</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/5 border-white/10">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-300 mb-4">
                  "La atención de ALEXIA es mejor que muchos vendedores humanos. Me ayudó a elegir la cobertura exacta
                  que necesitaba."
                </p>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center mr-3">
                    <span className="text-white font-bold text-sm">CS</span>
                  </div>
                  <div>
                    <div className="text-white font-semibold">Carla Sánchez</div>
                    <div className="text-gray-400 text-sm">Seguro de Salud</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Final */}
      <section className="py-20 bg-black/20">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="text-center max-w-4xl mx-auto">
            <h2 className="text-3xl lg:text-5xl font-bold text-white mb-6">
              🔥 ¿Listo para proteger lo que más querés?
            </h2>
            <p className="text-2xl text-gray-300 mb-4">No esperes a que sea tarde.</p>
            <p className="text-2xl text-blue-400 mb-8 font-semibold">Cotizá ahora y asegurate en minutos.</p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
              <Button
                size="lg"
                className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white px-8 py-4 text-lg"
              >
                <Calculator className="mr-2 h-5 w-5" />
                Cotizar Mi Seguro
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button
                size="lg"
                className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white px-8 py-4 text-lg"
              >
                <MessageCircle className="mr-2 h-5 w-5" />
                Hablar con ALEXIA
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-white/20 text-white hover:bg-white/10 px-8 py-4 text-lg"
              >
                <Phone className="mr-2 h-5 w-5" />
                Llamada Gratis
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
              <div>
                <div className="text-3xl font-bold text-blue-400">2 min</div>
                <div className="text-gray-400">Tiempo de cotización</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-blue-400">15+</div>
                <div className="text-gray-400">Aseguradoras comparadas</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-blue-400">24/7</div>
                <div className="text-gray-400">Atención disponible</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer id="contacto" className="border-t border-white/10 bg-black/20">
        <div className="container mx-auto px-4 lg:px-6 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-lg flex items-center justify-center">
                  <Shield className="h-5 w-5 text-white" />
                </div>
                <span className="text-white font-bold text-xl">SEGUROS INTELIGENTES</span>
              </div>
              <p className="text-gray-400 mb-4 max-w-md">
                Powered by MELANO INC. La plataforma de seguros más avanzada de Argentina. Protección inteligente para
                una vida sin preocupaciones.
              </p>
            </div>

            <div>
              <h3 className="text-white font-semibold mb-4">Seguros</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                    Auto
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                    Hogar
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                    Salud
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                    Vida
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-white font-semibold mb-4">Contacto</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                    WhatsApp
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                    Email
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                    Teléfono
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                    Chat ALEXIA
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-white/10 mt-8 pt-8 text-center">
            <p className="text-gray-400">
              © {new Date().getFullYear()} SEGUROS INTELIGENTES - Powered by MELANO INC.
              <span className="text-blue-400 ml-2">Protección que funciona.</span>
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
