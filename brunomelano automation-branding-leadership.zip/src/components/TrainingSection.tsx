import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { BookOpen, Code, Rocket, GitBranch, Zap, Brain } from "lucide-react";

const TrainingSection = () => {
  const modules = [
    {
      icon: Code,
      title: "Backend con FastAPI",
      description: "Automatizar flujos, APIs, bots",
      currentLevel: "Básico",
      progress: 30,
      nextAction: "Practicar endpoints reales",
      color: "from-blue-500 to-cyan-500"
    },
    {
      icon: Rocket,
      title: "Frontend con React",
      description: "Interfaces potentes, escalables",
      currentLevel: "Medio",
      progress: 60,
      nextAction: "Integrar con backend real",
      color: "from-purple-500 to-pink-500"
    },
    {
      icon: GitBranch,
      title: "Docker & Deployment",
      description: "Subir a producción como pro",
      currentLevel: "Bajo",
      progress: 20,
      nextAction: "Curso exprés + práctica",
      color: "from-green-500 to-emerald-500"
    },
    {
      icon: Brain,
      title: "Python Avanzado + IA",
      description: "Personalizar bots con ML",
      currentLevel: "Medio",
      progress: 50,
      nextAction: "Aplicar sobre Melania",
      color: "from-orange-500 to-red-500"
    },
    {
      icon: Zap,
      title: "Automations & Zapier/n8n",
      description: "Flujos sin código para escalar",
      currentLevel: "Alto",
      progress: 80,
      nextAction: "Escalar flujo de bots",
      color: "from-yellow-500 to-orange-500"
    },
    {
      icon: BookOpen,
      title: "Branding & Copy de Alto Nivel",
      description: "Impactar como marca premium",
      currentLevel: "Alto",
      progress: 85,
      nextAction: "Difusión y presencia",
      color: "from-indigo-500 to-purple-500"
    }
  ];

  const getLevelColor = (level: string) => {
    switch (level) {
      case "Alto": return "bg-green-100 text-green-800";
      case "Medio": return "bg-yellow-100 text-yellow-800";
      case "Bajo": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <section className="py-20 bg-gradient-to-b from-gray-900 to-black">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-orange-100 text-orange-800 hover:bg-orange-200">
            Plan de Entrenamiento
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Lo que te <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-red-400">Falta para Romperla</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Curso autodidacta personalizado para convertirte en CEO-Tech de tu propio stack.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {modules.map((module, index) => {
            const IconComponent = module.icon;
            return (
              <Card key={index} className="bg-white/10 backdrop-blur-lg border-white/20 hover:bg-white/15 transition-all duration-300">
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 bg-gradient-to-r ${module.color} rounded-lg`}>
                      <IconComponent className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1">
                      <CardTitle className="text-white text-lg">{module.title}</CardTitle>
                      <Badge className={`mt-1 ${getLevelColor(module.currentLevel)}`}>
                        {module.currentLevel}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300 text-sm mb-4">{module.description}</p>
                  
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-xs text-gray-400 mb-1">
                        <span>Progreso</span>
                        <span>{module.progress}%</span>
                      </div>
                      <Progress value={module.progress} className="h-2" />
                    </div>
                    
                    <div className="bg-white/5 rounded-lg p-3">
                      <p className="text-xs text-gray-400 mb-1">Próxima acción:</p>
                      <p className="text-sm text-white font-medium">{module.nextAction}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          <Card className="bg-gradient-to-br from-orange-600/20 to-red-600/20 backdrop-blur-lg border-orange-500/30">
            <CardHeader>
              <CardTitle className="text-white text-xl">📚 Entrega del Curso</CardTitle>
            </CardHeader>
            <CardContent className="text-gray-300">
              <ul className="space-y-2 text-sm">
                <li className="flex items-center space-x-2">
                  <div className="w-1.5 h-1.5 bg-orange-400 rounded-full"></div>
                  <span>Plantilla en Notion interactiva</span>
                </li>
                <li className="flex items-center space-x-2">
                  <div className="w-1.5 h-1.5 bg-orange-400 rounded-full"></div>
                  <span>PDF con links y ejercicios</span>
                </li>
                <li className="flex items-center space-x-2">
                  <div className="w-1.5 h-1.5 bg-orange-400 rounded-full"></div>
                  <span>Prácticas funcionales por nivel</span>
                </li>
                <li className="flex items-center space-x-2">
                  <div className="w-1.5 h-1.5 bg-orange-400 rounded-full"></div>
                  <span>Proyectos reales para practicar</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-600/20 to-cyan-600/20 backdrop-blur-lg border-purple-500/30">
            <CardHeader>
              <CardTitle className="text-white text-xl">🎯 Objetivo Final</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-300 text-sm mb-4">
                Al completar este entrenamiento, vas a ser completamente independiente para:
              </p>
              <ul className="space-y-2 text-sm text-gray-300">
                <li className="flex items-center space-x-2">
                  <div className="w-1.5 h-1.5 bg-cyan-400 rounded-full"></div>
                  <span>Crear y deployar tus propios bots</span>
                </li>
                <li className="flex items-center space-x-2">
                  <div className="w-1.5 h-1.5 bg-cyan-400 rounded-full"></div>
                  <span>Escalar sistemas sin depender de nadie</span>
                </li>
                <li className="flex items-center space-x-2">
                  <div className="w-1.5 h-1.5 bg-cyan-400 rounded-full"></div>
                  <span>Liderar técnicamente tu empresa</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>

        <div className="text-center mt-12">
          <Button size="lg" className="bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 px-8 py-4">
            <BookOpen className="mr-2 w-5 h-5" />
            Acceder al Entrenamiento Completo
          </Button>
        </div>
      </div>
    </section>
  );
};

export default TrainingSection;