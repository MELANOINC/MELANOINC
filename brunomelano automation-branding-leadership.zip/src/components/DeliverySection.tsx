import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle, Package, Mail, MessageSquare, Clock } from "lucide-react";

const DeliverySection = () => {
  const deliverables = [
    {
      icon: "📄",
      title: "Manifiesto MELANO INC",
      description: "PDF profesional + versión web",
      status: "Listo"
    },
    {
      icon: "📲",
      title: "Carrusel Visual",
      description: "PNG para Instagram/LinkedIn + Canva editable",
      status: "Listo"
    },
    {
      icon: "🎬",
      title: "Pitch en Video",
      description: "MP4 + audio + frames + proyecto AE",
      status: "Listo"
    },
    {
      icon: "👤",
      title: "LinkedIn Bio Optimizada",
      description: "Copy listo para copiar y pegar",
      status: "Listo"
    },
    {
      icon: "🌐",
      title: "Landing de Autoridad",
      description: "ZIP completo para Hostinger",
      status: "Listo"
    },
    {
      icon: "🧠",
      title: "Plan de Entrenamiento",
      description: "Notion + PDF interactivo",
      status: "Listo"
    }
  ];

  const channels = [
    {
      icon: Mail,
      title: "Email",
      description: "melanobruno@gmail.com",
      color: "from-blue-500 to-cyan-500"
    },
    {
      icon: MessageSquare,
      title: "WhatsApp",
      description: "Envío directo + notificación",
      color: "from-green-500 to-emerald-500"
    },
    {
      icon: Package,
      title: "ZIP Completo",
      description: "Todos los archivos organizados",
      color: "from-purple-500 to-pink-500"
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-emerald-100 text-emerald-800 hover:bg-emerald-200">
            Kit Completo
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Todo <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 to-green-600">Listo para Entregar</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Tu kit completo de referente en automatización con IA. Listo para impactar desde el primer día.
          </p>
        </div>

        {/* Deliverables Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {deliverables.map((item, index) => (
            <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <span className="text-2xl">{item.icon}</span>
                    <CardTitle className="text-lg">{item.title}</CardTitle>
                  </div>
                  <CheckCircle className="w-5 h-5 text-green-500" />
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-sm mb-3">{item.description}</p>
                <Badge className="bg-green-100 text-green-800">
                  ✓ {item.status}
                </Badge>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Delivery Channels */}
        <div className="mb-16">
          <h3 className="text-2xl font-bold text-gray-900 text-center mb-8">Canales de Entrega</h3>
          <div className="grid md:grid-cols-3 gap-6">
            {channels.map((channel, index) => {
              const IconComponent = channel.icon;
              return (
                <Card key={index} className="text-center border-0 shadow-lg">
                  <CardContent className="p-6">
                    <div className={`w-16 h-16 bg-gradient-to-r ${channel.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                      <IconComponent className="w-8 h-8 text-white" />
                    </div>
                    <h4 className="text-lg font-semibold text-gray-900 mb-2">{channel.title}</h4>
                    <p className="text-gray-600 text-sm">{channel.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Timeline */}
        <Card className="bg-gradient-to-r from-gray-900 to-gray-800 text-white border-0 mb-12">
          <CardHeader>
            <div className="flex items-center space-x-3">
              <Clock className="w-6 h-6 text-emerald-400" />
              <CardTitle className="text-xl">Timeline de Entrega</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6 text-center">
              <div>
                <div className="text-3xl font-bold text-emerald-400 mb-2">HOY</div>
                <p className="text-gray-300 text-sm">Manifiesto + Carrusel + LinkedIn Bio</p>
              </div>
              <div>
                <div className="text-3xl font-bold text-emerald-400 mb-2">24H</div>
                <p className="text-gray-300 text-sm">Video + Landing + Entrenamiento</p>
              </div>
              <div>
                <div className="text-3xl font-bold text-emerald-400 mb-2">48H</div>
                <p className="text-gray-300 text-sm">Difusión automatizada activada</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Final CTA */}
        <div className="text-center">
          <Card className="bg-gradient-to-r from-emerald-600 to-green-600 text-white border-0 inline-block">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold mb-4">🚀 Activación Inmediata</h3>
              <p className="text-emerald-100 mb-6 max-w-2xl">
                Todo está listo para lanzar tu posicionamiento como referente. 
                Solo falta tu confirmación para activar el sistema completo.
              </p>
              <div className="space-y-4">
                <Button size="lg" variant="secondary" className="bg-white text-emerald-600 hover:bg-gray-100 mr-4">
                  <Package className="mr-2 w-5 h-5" />
                  Descargar Kit Completo
                </Button>
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                  <MessageSquare className="mr-2 w-5 h-5" />
                  Activar Difusión
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default DeliverySection;