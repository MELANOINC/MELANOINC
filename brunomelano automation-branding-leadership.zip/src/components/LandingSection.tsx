import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Globe, Download, Smartphone, Monitor, Code } from "lucide-react";

const LandingSection = () => {
  const features = [
    {
      icon: Globe,
      title: "Dominio Personalizado",
      description: "brunomelano.com/autoridad - URL profesional y memorable"
    },
    {
      icon: Smartphone,
      title: "Responsive Design",
      description: "Optimizado para móvil, tablet y desktop"
    },
    {
      icon: Monitor,
      title: "Demos en Vivo",
      description: "Melania, Luxia y Alenya funcionando en tiempo real"
    },
    {
      icon: Code,
      title: "Fácil Deploy",
      description: "ZIP listo para subir a Hostinger en minutos"
    }
  ];

  const sections = [
    "Hero con tu foto y mensaje de impacto",
    "Frases clave que definen tu autoridad",
    "Tu historia: de Mar del Plata al mundo",
    "Showcase de bots en funcionamiento",
    "Casos de éxito y testimonios",
    "Visión de futuro de la automatización",
    "Botón directo a WhatsApp",
    "Formulario de contacto integrado"
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-green-100 text-green-800 hover:bg-green-200">
            Landing de Autoridad
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Tu <span className="text-transparent bg-clip-text bg-gradient-to-r from-green-600 to-emerald-600">Presencia Digital</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Página web profesional que establece tu autoridad como líder en automatización con IA.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Preview */}
          <div className="space-y-6">
            <Card className="overflow-hidden shadow-xl">
              <CardContent className="p-0">
                <div className="bg-gradient-to-br from-gray-900 to-gray-800 p-8 text-white">
                  <div className="flex items-center space-x-4 mb-6">
                    <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center">
                      <span className="text-2xl font-bold">BM</span>
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold">Bruno Melano</h3>
                      <p className="text-gray-300">CEO MELANO INC</p>
                    </div>
                  </div>
                  <h4 className="text-xl font-semibold mb-3">"No vendo cursos de IA."</h4>
                  <p className="text-gray-300 mb-4">"Creo sistemas que venden por vos."</p>
                  <div className="space-y-2">
                    <div className="h-2 bg-gray-700 rounded"></div>
                    <div className="h-2 bg-gray-700 rounded w-3/4"></div>
                    <div className="h-2 bg-gray-700 rounded w-1/2"></div>
                  </div>
                </div>
                <div className="bg-white p-6">
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center">
                      <div className="w-12 h-12 bg-pink-100 rounded-lg mx-auto mb-2"></div>
                      <p className="text-xs text-gray-600">Melania</p>
                    </div>
                    <div className="text-center">
                      <div className="w-12 h-12 bg-purple-100 rounded-lg mx-auto mb-2"></div>
                      <p className="text-xs text-gray-600">Luxia</p>
                    </div>
                    <div className="text-center">
                      <div className="w-12 h-12 bg-cyan-100 rounded-lg mx-auto mb-2"></div>
                      <p className="text-xs text-gray-600">Alenya</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <p className="text-center text-gray-600 text-sm">
              Vista previa del diseño responsive
            </p>
          </div>

          {/* Features & Content */}
          <div className="space-y-8">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Características Técnicas</h3>
              <div className="grid grid-cols-2 gap-4">
                {features.map((feature, index) => {
                  const IconComponent = feature.icon;
                  return (
                    <div key={index} className="flex items-start space-x-3">
                      <div className="p-2 bg-green-100 rounded-lg">
                        <IconComponent className="w-5 h-5 text-green-600" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900 text-sm">{feature.title}</h4>
                        <p className="text-gray-600 text-xs">{feature.description}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Secciones Incluidas</h3>
              <div className="space-y-2">
                {sections.map((section, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-gray-700 text-sm">{section}</span>
                  </div>
                ))}
              </div>
            </div>

            <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
              <CardHeader>
                <CardTitle className="text-green-800">Entrega Completa</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-green-700">Código HTML/CSS/JS</span>
                    <Badge variant="secondary">✓ Incluido</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-green-700">Imágenes optimizadas</span>
                    <Badge variant="secondary">✓ Incluido</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-green-700">Instrucciones de deploy</span>
                    <Badge variant="secondary">✓ Incluido</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-green-700">Soporte técnico</span>
                    <Badge variant="secondary">✓ Incluido</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Button size="lg" className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700">
              <Download className="mr-2 w-5 h-5" />
              Generar Landing Completa
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default LandingSection;