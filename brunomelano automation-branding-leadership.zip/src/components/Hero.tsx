import { Button } from "@/components/ui/button";
import { ArrowRight, Bot, Zap } from "lucide-react";

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 w-full h-full">
        <div className="absolute top-20 left-10 w-72 h-72 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
        <div className="absolute top-40 right-10 w-72 h-72 bg-cyan-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse animation-delay-2000"></div>
        <div className="absolute -bottom-8 left-20 w-72 h-72 bg-pink-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse animation-delay-4000"></div>
      </div>
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="space-y-8">
          {/* Main headline */}
          <h1 className="text-5xl md:text-7xl font-bold text-white leading-tight">
            Desde <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-cyan-400">Mar del Plata</span>
            <br />al mundo
          </h1>
          
          {/* Subheadline */}
          <h2 className="text-2xl md:text-3xl text-gray-300 font-light max-w-4xl mx-auto">
            Por qué <span className="font-bold text-white">MELANO INC</span> no es una empresa...
            <br />es un <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400">movimiento de automatización real</span>
          </h2>
          
          {/* Key points */}
          <div className="grid md:grid-cols-3 gap-8 mt-16 max-w-5xl mx-auto">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <Bot className="w-12 h-12 text-cyan-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">Bots Reales</h3>
              <p className="text-gray-300">No promesas. Sistemas que trabajan 24/7</p>
            </div>
            
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <Zap className="w-12 h-12 text-purple-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">IA que Vende</h3>
              <p className="text-gray-300">Mientras otros postean, yo ya estoy vendiendo</p>
            </div>
            
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <ArrowRight className="w-12 h-12 text-pink-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">Visión Global</h3>
              <p className="text-gray-300">Negocios sin fricción, poder creativo</p>
            </div>
          </div>
          
          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mt-12">
            <Button size="lg" className="bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-700 hover:to-cyan-700 text-white px-8 py-4 text-lg">
              Ver el Manifiesto
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
            <Button size="lg" variant="outline" className="border-white/30 text-white hover:bg-white/10 px-8 py-4 text-lg">
              Conocer los Bots
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;