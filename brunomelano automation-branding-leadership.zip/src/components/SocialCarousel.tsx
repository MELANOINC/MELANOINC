import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Instagram, Linkedin, Share2 } from "lucide-react";

const SocialCarousel = () => {
  const slides = [
    {
      text: "Mientras otros postean sobre IA,",
      highlight: "yo ya estoy vendiendo con IA.",
      gradient: "from-pink-500 to-rose-500"
    },
    {
      text: "No es un experimento.",
      highlight: "Es un sistema.",
      gradient: "from-purple-500 to-violet-500"
    },
    {
      text: "Melano INC: bots que trabajan",
      highlight: "mientras vos creás imperios.",
      gradient: "from-cyan-500 to-blue-500"
    },
    {
      text: "De Mar del Plata al mundo:",
      highlight: "automatización que funciona.",
      gradient: "from-emerald-500 to-teal-500"
    },
    {
      text: "No vendo cursos de IA.",
      highlight: "Creo sistemas que venden por vos.",
      gradient: "from-orange-500 to-red-500"
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-pink-100 text-pink-800 hover:bg-pink-200">
            Carrusel para Redes
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Contenido <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-600 to-purple-600">Viral</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Frases potentes diseñadas para impactar en Instagram y LinkedIn. Estilo Apple, máximo impacto.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {slides.map((slide, index) => (
            <Card key={index} className="overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
              <CardContent className="p-0">
                <div className={`bg-gradient-to-br ${slide.gradient} p-8 text-white min-h-[200px] flex flex-col justify-center`}>
                  <div className="text-center space-y-4">
                    <p className="text-lg font-medium opacity-90">{slide.text}</p>
                    <p className="text-xl font-bold">{slide.highlight}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
          
          {/* CEO Card */}
          <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 md:col-span-2 lg:col-span-1">
            <CardContent className="p-0">
              <div className="bg-gradient-to-br from-gray-900 to-gray-800 p-8 text-white min-h-[200px] flex flex-col justify-center items-center">
                <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-cyan-500 rounded-full mb-4 flex items-center justify-center">
                  <span className="text-2xl font-bold">BM</span>
                </div>
                <h3 className="text-xl font-bold mb-2">Bruno Melano</h3>
                <p className="text-sm opacity-90 text-center">CEO MELANO INC</p>
                <p className="text-xs opacity-75 mt-2 text-center">Escanea el QR para hablar con Melania Bot</p>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="text-center space-y-6">
          <h3 className="text-2xl font-bold text-gray-900">Listos para Compartir</h3>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Cada slide está optimizado para Instagram Stories, LinkedIn posts y contenido viral. 
            Formato PNG de alta calidad + versión editable en Canva.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700">
              <Instagram className="mr-2 w-5 h-5" />
              Descargar para Instagram
            </Button>
            <Button variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-50">
              <Linkedin className="mr-2 w-5 h-5" />
              Descargar para LinkedIn
            </Button>
            <Button variant="outline">
              <Share2 className="mr-2 w-5 h-5" />
              Obtener Editables
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SocialCarousel;