import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Play, Download, Volume2, Video } from "lucide-react";

const VideoSection = () => {
  return (
    <section className="py-20 bg-gray-900">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-purple-100 text-purple-800 hover:bg-purple-200">
            Pitch en Video
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            El <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-cyan-400">Teaser</span> Definitivo
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Video animado con voz femenina ejecutiva, estética futurista y tu presencia como CEO.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Video Preview */}
          <div className="relative">
            <Card className="bg-white/10 backdrop-blur-lg border-white/20 overflow-hidden">
              <CardContent className="p-0">
                <div className="relative aspect-video bg-gradient-to-br from-purple-900 to-cyan-900 flex items-center justify-center">
                  <div className="absolute inset-0 bg-black/20"></div>
                  <div className="relative z-10 text-center">
                    <div className="w-20 h-20 bg-white/20 backdrop-blur-lg rounded-full flex items-center justify-center mb-4 mx-auto">
                      <Play className="w-8 h-8 text-white ml-1" />
                    </div>
                    <p className="text-white font-medium">Vista Previa del Pitch</p>
                    <p className="text-gray-300 text-sm mt-1">Duración: 60 segundos</p>
                  </div>
                  
                  {/* Animated elements */}
                  <div className="absolute top-4 left-4 w-2 h-2 bg-cyan-400 rounded-full animate-pulse"></div>
                  <div className="absolute top-8 right-8 w-2 h-2 bg-purple-400 rounded-full animate-pulse animation-delay-1000"></div>
                  <div className="absolute bottom-4 left-8 w-2 h-2 bg-pink-400 rounded-full animate-pulse animation-delay-2000"></div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Video Details */}
          <div className="space-y-8">
            <div>
              <h3 className="text-2xl font-bold text-white mb-4">Características del Video</h3>
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Volume2 className="w-5 h-5 text-cyan-400" />
                  <span className="text-gray-300">Voz femenina ejecutiva con acento colombiano</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Video className="w-5 h-5 text-purple-400" />
                  <span className="text-gray-300">Estética futurista con líneas de código</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Play className="w-5 h-5 text-pink-400" />
                  <span className="text-gray-300">Fragmentos de bots trabajando en tiempo real</span>
                </div>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h4 className="text-lg font-semibold text-white mb-3">Script del Pitch</h4>
              <div className="space-y-2 text-gray-300 text-sm">
                <p>"Soy Bruno Melano, CEO de MELANO INC."</p>
                <p>"Desde Mar del Plata, estoy revolucionando la automatización con IA."</p>
                <p>"Mis bots no son promesas. Son sistemas que trabajan 24/7."</p>
                <p className="font-semibold text-white">"MELANO INC: donde la IA se convierte en resultados reales."</p>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="text-lg font-semibold text-white">Formatos de Entrega</h4>
              <div className="grid grid-cols-2 gap-4">
                <Button variant="outline" className="border-white/30 text-white hover:bg-white/10">
                  <Download className="mr-2 w-4 h-4" />
                  Video MP4
                </Button>
                <Button variant="outline" className="border-white/30 text-white hover:bg-white/10">
                  <Download className="mr-2 w-4 h-4" />
                  Audio WAV
                </Button>
                <Button variant="outline" className="border-white/30 text-white hover:bg-white/10">
                  <Download className="mr-2 w-4 h-4" />
                  Frames PNG
                </Button>
                <Button variant="outline" className="border-white/30 text-white hover:bg-white/10">
                  <Download className="mr-2 w-4 h-4" />
                  Proyecto AE
                </Button>
              </div>
            </div>

            <Button size="lg" className="w-full bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-700 hover:to-cyan-700">
              Generar Video Completo
              <Play className="ml-2 w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default VideoSection;