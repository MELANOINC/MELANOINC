import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Bot, MessageSquare, Calendar, TrendingUp, ExternalLink } from "lucide-react";

const BotsShowcase = () => {
  const bots = [
    {
      name: "Melania",
      description: "Bot de ventas con IA que califica leads y programa reuniones automáticamente",
      features: ["Calificación de leads", "Programación automática", "Follow-up inteligente"],
      status: "Activo",
      icon: MessageSquare,
      color: "from-pink-500 to-rose-500"
    },
    {
      name: "Luxia",
      description: "Asistente de atención al cliente que resuelve consultas 24/7",
      features: ["Soporte 24/7", "Resolución automática", "Escalado inteligente"],
      status: "Activo",
      icon: Bot,
      color: "from-purple-500 to-violet-500"
    },
    {
      name: "Alenya",
      description: "Bot de análisis que procesa datos y genera reportes automáticos",
      features: ["Análisis de datos", "Reportes automáticos", "Insights en tiempo real"],
      status: "En desarrollo",
      icon: TrendingUp,
      color: "from-cyan-500 to-blue-500"
    }
  ];

  return (
    <section className="py-20 bg-gray-900">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-cyan-100 text-cyan-800 hover:bg-cyan-200">
            Ecosistema de Bots
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Bots que <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400">Trabajan por Vos</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Cada bot está diseñado para una función específica. Juntos forman un sistema completo de automatización.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {bots.map((bot, index) => {
            const IconComponent = bot.icon;
            return (
              <Card key={index} className="bg-white/10 backdrop-blur-lg border-white/20 hover:bg-white/15 transition-all duration-300">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={`p-3 bg-gradient-to-r ${bot.color} rounded-xl`}>
                        <IconComponent className="w-6 h-6 text-white" />
                      </div>
                      <CardTitle className="text-xl text-white">{bot.name}</CardTitle>
                    </div>
                    <Badge 
                      variant={bot.status === "Activo" ? "default" : "secondary"}
                      className={bot.status === "Activo" ? "bg-green-500 hover:bg-green-600" : ""}
                    >
                      {bot.status}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300 mb-4">{bot.description}</p>
                  <ul className="space-y-2 mb-6">
                    {bot.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center text-sm text-gray-400">
                        <div className="w-1.5 h-1.5 bg-cyan-400 rounded-full mr-2"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Button 
                    variant="outline" 
                    className="w-full border-white/30 text-white hover:bg-white/10"
                    disabled={bot.status !== "Activo"}
                  >
                    {bot.status === "Activo" ? "Ver Demo" : "Próximamente"}
                    {bot.status === "Activo" && <ExternalLink className="ml-2 w-4 h-4" />}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="text-center">
          <div className="bg-gradient-to-r from-purple-600/20 to-cyan-600/20 backdrop-blur-lg rounded-2xl p-8 border border-white/20">
            <Calendar className="w-12 h-12 text-cyan-400 mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-white mb-4">¿Querés ver cómo funcionan?</h3>
            <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
              Programá una demo personalizada y te muestro cómo estos bots pueden transformar tu negocio.
            </p>
            <Button size="lg" className="bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-700 hover:to-cyan-700">
              Programar Demo
              <Calendar className="ml-2 w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BotsShowcase;