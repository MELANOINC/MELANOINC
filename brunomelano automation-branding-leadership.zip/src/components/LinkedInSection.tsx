import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Copy, Linkedin, User, Briefcase } from "lucide-react";

const LinkedInSection = () => {
  const profileData = {
    headline: "CEO de MELANO INC | Bots que escalan negocios | SaaS + IA + Automatización real",
    about: `🚀 Desde Mar del Plata al mundo: construyo sistemas de IA que realmente funcionan.

💡 No vendo cursos sobre automatización. Creo bots que automatizan negocios reales:
• Melania: Bot de ventas que califica leads y programa reuniones
• Luxia: Asistente de atención al cliente 24/7
• Alenya: Análisis de datos e insights automáticos

🎯 Mi misión: liberar el poder creativo humano a través de la automatización inteligente.

📍 Mar del Plata, Argentina | 🌍 Impacto Global

¿Tu negocio está listo para la automatización real? Conectemos.`,
    experience: "CEO & Founder en MELANO INC - Automatización con IA que funciona",
    skills: ["Automatización con IA", "Desarrollo de Bots", "SaaS", "Python", "FastAPI", "React"]
  };

  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    // In a real app, you'd show a toast notification here
    console.log(`${type} copiado al portapapeles`);
  };

  return (
    <section className="py-20 bg-gradient-to-b from-white to-blue-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-blue-100 text-blue-800 hover:bg-blue-200">
            Optimización LinkedIn
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Perfil de <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-cyan-600">Autoridad</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Copy profesional optimizado para posicionarte como líder en automatización con IA.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Headline */}
          <Card className="shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader>
              <div className="flex items-center space-x-3">
                <Briefcase className="w-6 h-6 text-blue-600" />
                <CardTitle>Titular Profesional</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <div className="bg-gray-50 rounded-lg p-4 mb-4">
                <p className="text-gray-800 font-medium">{profileData.headline}</p>
              </div>
              <Button 
                onClick={() => copyToClipboard(profileData.headline, 'Titular')}
                className="w-full"
                variant="outline"
              >
                <Copy className="mr-2 w-4 h-4" />
                Copiar Titular
              </Button>
            </CardContent>
          </Card>

          {/* About Section */}
          <Card className="shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader>
              <div className="flex items-center space-x-3">
                <User className="w-6 h-6 text-blue-600" />
                <CardTitle>Sección "Acerca de"</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <div className="bg-gray-50 rounded-lg p-4 mb-4 max-h-48 overflow-y-auto">
                <pre className="text-gray-800 text-sm whitespace-pre-wrap font-sans">{profileData.about}</pre>
              </div>
              <Button 
                onClick={() => copyToClipboard(profileData.about, 'Descripción')}
                className="w-full"
                variant="outline"
              >
                <Copy className="mr-2 w-4 h-4" />
                Copiar Descripción
              </Button>
            </CardContent>
          </Card>

          {/* Experience */}
          <Card className="shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader>
              <CardTitle>Experiencia Actual</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="bg-gray-50 rounded-lg p-4 mb-4">
                <p className="text-gray-800 font-medium">{profileData.experience}</p>
              </div>
              <Button 
                onClick={() => copyToClipboard(profileData.experience, 'Experiencia')}
                className="w-full"
                variant="outline"
              >
                <Copy className="mr-2 w-4 h-4" />
                Copiar Experiencia
              </Button>
            </CardContent>
          </Card>

          {/* Skills */}
          <Card className="shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader>
              <CardTitle>Habilidades Clave</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2 mb-4">
                {profileData.skills.map((skill, index) => (
                  <Badge key={index} variant="secondary" className="bg-blue-100 text-blue-800">
                    {skill}
                  </Badge>
                ))}
              </div>
              <Button 
                onClick={() => copyToClipboard(profileData.skills.join(', '), 'Habilidades')}
                className="w-full"
                variant="outline"
              >
                <Copy className="mr-2 w-4 h-4" />
                Copiar Habilidades
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="mt-12 text-center">
          <Card className="bg-gradient-to-r from-blue-600 to-cyan-600 text-white border-0">
            <CardContent className="p-8">
              <Linkedin className="w-12 h-12 mx-auto mb-4" />
              <h3 className="text-2xl font-bold mb-4">Listo para LinkedIn</h3>
              <p className="text-blue-100 mb-6 max-w-2xl mx-auto">
                Todo el copy está optimizado para algoritmos de LinkedIn y diseñado para generar conexiones de alto valor.
              </p>
              <Button size="lg" variant="secondary" className="bg-white text-blue-600 hover:bg-gray-100">
                <Linkedin className="mr-2 w-5 h-5" />
                Abrir LinkedIn
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default LinkedInSection;