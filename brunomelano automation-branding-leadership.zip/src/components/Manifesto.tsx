import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { User, Target, Cog, Lightbulb } from "lucide-react";

const Manifesto = () => {
  const sections = [
    {
      icon: User,
      title: "Quién soy y por qué lo hago",
      content: "Soy Bruno Melano, desde Mar del Plata. No soy otro gurú de IA que vende humo. Soy alguien que programa, que ejecuta, que construye sistemas reales. Empecé automatizando mi propio negocio y ahora ayudo a otros a hacer lo mismo."
    },
    {
      icon: Target,
      title: "Qué es MELANO INC y por qué es diferente",
      content: "MELANO INC no es una consultora más. Es un ecosistema de bots inteligentes que trabajan mientras vos dormís. Melania, Luxia, Alenya - cada bot tiene un propósito específico y resultados medibles."
    },
    {
      icon: Cog,
      title: "Automatización real, no promesas",
      content: "Mientras otros hablan de IA, yo la implemento. Mis bots procesan leads, califican clientes, programan reuniones y cierran ventas. No es teoría, es código funcionando en producción."
    },
    {
      icon: Lightbulb,
      title: "Mi visión de futuro",
      content: "Veo un mundo donde la IA libera el poder creativo humano. Donde los emprendedores se enfocan en crear valor, no en tareas repetitivas. Donde los negocios escalan sin fricción."
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-purple-100 text-purple-800 hover:bg-purple-200">
            Manifiesto Oficial
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            El Movimiento de
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-cyan-600"> Automatización Real</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Este no es otro pitch de startup. Es la declaración de un nuevo paradigma en automatización con IA.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {sections.map((section, index) => {
            const IconComponent = section.icon;
            return (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow duration-300 bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-gradient-to-r from-purple-500 to-cyan-500 rounded-lg">
                      <IconComponent className="w-6 h-6 text-white" />
                    </div>
                    <CardTitle className="text-xl text-gray-900">{section.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 leading-relaxed">{section.content}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-purple-600 to-cyan-600 rounded-2xl p-8 text-white">
            <h3 className="text-2xl font-bold mb-4">La Diferencia MELANO</h3>
            <p className="text-lg opacity-90 max-w-3xl mx-auto">
              "No es un experimento. Es un sistema. Melano INC: bots que trabajan mientras vos creás imperios."
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Manifesto;