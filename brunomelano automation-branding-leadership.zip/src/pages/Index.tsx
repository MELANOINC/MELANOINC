import React from 'react';
import Hero from '@/components/Hero';
import Manifesto from '@/components/Manifesto';
import BotsShowcase from '@/components/BotsShowcase';
import SocialCarousel from '@/components/SocialCarousel';
import VideoSection from '@/components/VideoSection';
import LinkedInSection from '@/components/LinkedInSection';
import LandingSection from '@/components/LandingSection';
import TrainingSection from '@/components/TrainingSection';
import DeliverySection from '@/components/DeliverySection';

const Index: React.FC = () => {
  return (
    <div className="min-h-screen">
      <Hero />
      <Manifesto />
      <BotsShowcase />
      <SocialCarousel />
      <VideoSection />
      <LinkedInSection />
      <LandingSection />
      <TrainingSection />
      <DeliverySection />
    </div>
  );
};

export default Index;