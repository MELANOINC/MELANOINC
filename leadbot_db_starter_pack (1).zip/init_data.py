
import psycopg2
import os

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://user:password@localhost:5432/leadbot")

def run_seed():
    seed_statements = [
        "INSERT INTO users (email, password_hash, role, company_name) VALUES ('admin@melano.inc', 'hashed_admin_pass', 'admin', 'MELANO INC');"
    ]
    try:
        conn = psycopg2.connect(DATABASE_URL)
        cur = conn.cursor()
        for stmt in seed_statements:
            cur.execute(stmt)
        conn.commit()
        cur.close()
        conn.close()
        print("✅ Datos de prueba insertados correctamente.")
    except Exception as e:
        print("❌ Error al insertar datos:", e)

if __name__ == "__main__":
    run_seed()
