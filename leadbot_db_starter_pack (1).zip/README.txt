
MELANO INC – LeadBot DB Starter Pack

Incluye:

1. leadbot_schema_expert_postgresql.sql
   - Esquema relacional experto para PostgreSQL
   - Incluye usuarios, leads, campañas, bots, métricas y eventos
   - Validaciones CHECK, claves foráneas, normalización lista para escalar

2. leadbot_seed_postgresql.sql
   - Datos de prueba para usuarios, leads, campañas y bots
   - Ideal para testing y mostrar el flujo completo en entorno demo

3. init_data.py
   - Script Python para insertar los datos de prueba en la base PostgreSQL desde código
   - Usa la variable de entorno DATABASE_URL

Instrucciones de uso:

1. Crear la base de datos PostgreSQL `leadbot`
2. Ejecutar el esquema SQL:
   psql -U <usuario> -d leadbot -f leadbot_schema_expert_postgresql.sql

3. Insertar datos de prueba:
   Opción A: 
     psql -U <usuario> -d leadbot -f leadbot_seed_postgresql.sql
   Opción B:
     python init_data.py

Este pack es ideal para desarrolladores que trabajen en la plataforma SaaS LeadBot Pro de MELANO INC.
