
INSERT INTO users (email, password_hash, role, company_name) VALUES
('admin@melano.inc', 'hashed_admin_pass', 'admin', 'MELANO INC'),
('cliente@empresa.com', 'hashed_client_pass', 'client', 'Empresa Cliente');
