/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#f0f4fe',
          100: '#d9e2fc',
          200: '#bacefa',
          300: '#8eaff5',
          400: '#608aee',
          500: '#3f67e6',
          600: '#2a4add',
          700: '#2239cc',
          800: '#2231a5',
          900: '#213182',
          950: '#121c4d',
        },
        secondary: {
          50: '#f4f3ff',
          100: '#ebe9fe',
          200: '#d9d5fd',
          300: '#bcb4fb',
          400: '#9b88f8',
          500: '#7c5bf4',
          600: '#6e3ceb',
          700: '#5f2ad8',
          800: '#4f24b3',
          900: '#422292',
          950: '#271359',
        },
        accent: {
          50: '#fdf4ff',
          100: '#fae8ff',
          200: '#f5d0fe',
          300: '#f0abfc',
          400: '#e879f9',
          500: '#d946ef',
          600: '#c026d3',
          700: '#a21caf',
          800: '#86198f',
          900: '#701a75',
          950: '#4a044e',
        },
      },
      animation: {
        'float': 'float 6s ease-in-out infinite',
        'pulse-slow': 'pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-10px)' },
        },
      },
    },
  },
  plugins: [],
};