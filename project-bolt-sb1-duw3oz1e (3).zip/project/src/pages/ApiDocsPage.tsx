import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { tomorrow } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { Terminal, Copy, Check, BookOpen, Code, Shield, Server, ArrowRight, Database, Users } from 'lucide-react';

interface ApiMethod {
  id: string;
  title: string;
  description: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  url: string;
  request: string;
  response: string;
  authentication: boolean;
  params?: {
    name: string;
    type: string;
    required: boolean;
    description: string;
  }[];
}

const apiMethods: ApiMethod[] = [
  {
    id: 'evento',
    title: 'Enviar Evento',
    description: 'Envía un evento al sistema para ser procesado por el agente correspondiente.',
    method: 'POST',
    url: '/evento',
    request: `POST /evento
Content-Type: application/json

{
  "id": "1234",
  "source": "SalesX",
  "type": "new_lead",
  "payload": {
    "lead_name": "Juan Pérez",
    "email": "juan.perez@example.com",
    "phone": "+34600123456",
    "interest": "Agent.InvestAlpha"
  }
}`,
    response: `HTTP/1.1 200 OK
Content-Type: application/json

{
  "success": true,
  "event_id": "1234",
  "processed_by": "Agent.SalesX",
  "message": "Evento procesado correctamente"
}`,
    authentication: true,
    params: [
      {
        name: 'id',
        type: 'string',
        required: true,
        description: 'Identificador único del evento'
      },
      {
        name: 'source',
        type: 'string',
        required: true,
        description: 'Agente que origina el evento'
      },
      {
        name: 'type',
        type: 'string',
        required: true,
        description: 'Tipo de evento (new_lead, signal_trade, etc.)'
      },
      {
        name: 'payload',
        type: 'object',
        required: true,
        description: 'Datos específicos del evento'
      }
    ]
  },
  {
    id: 'agente',
    title: 'Consultar Agente',
    description: 'Obtiene información sobre un agente específico y su estado actual.',
    method: 'GET',
    url: '/agente/{agent_id}',
    request: `GET /agente/salesx
Authorization: Bearer {api_token}`,
    response: `HTTP/1.1 200 OK
Content-Type: application/json

{
  "id": "salesx",
  "name": "Agent.SalesX",
  "status": "active",
  "version": "1.2.3",
  "events_processed_today": 245,
  "last_activity": "2025-03-15T14:23:45Z",
  "capabilities": [
    "lead_qualification",
    "conversation",
    "sales_funnel"
  ]
}`,
    authentication: true,
    params: [
      {
        name: 'agent_id',
        type: 'string',
        required: true,
        description: 'Identificador del agente (salesx, investalpha, etc.)'
      }
    ]
  },
  {
    id: 'pipeline',
    title: 'Crear Pipeline',
    description: 'Crea un flujo de trabajo personalizado combinando varios agentes.',
    method: 'POST',
    url: '/pipeline',
    request: `POST /pipeline
Content-Type: application/json
Authorization: Bearer {api_token}

{
  "name": "lead_to_content",
  "description": "Procesa un lead y genera contenido personalizado",
  "stages": [
    {
      "agent": "Agent.SalesX",
      "action": "qualify_lead",
      "config": { "min_score": 0.7 }
    },
    {
      "agent": "Agent.IAContent",
      "action": "generate_email",
      "config": { "template": "welcome", "personalize": true }
    }
  ]
}`,
    response: `HTTP/1.1 201 Created
Content-Type: application/json

{
  "pipeline_id": "pl_8f72a5",
  "name": "lead_to_content",
  "status": "active",
  "created_at": "2025-03-15T15:30:00Z"
}`,
    authentication: true,
    params: [
      {
        name: 'name',
        type: 'string',
        required: true,
        description: 'Nombre identificativo del pipeline'
      },
      {
        name: 'description',
        type: 'string',
        required: false,
        description: 'Descripción del propósito del pipeline'
      },
      {
        name: 'stages',
        type: 'array',
        required: true,
        description: 'Array de etapas del pipeline con agentes y acciones'
      }
    ]
  },
  {
    id: 'resultados',
    title: 'Obtener Resultados',
    description: 'Consulta los resultados de un agente o pipeline específico.',
    method: 'GET',
    url: '/resultados',
    request: `GET /resultados?agent_id=salesx&date_from=2025-03-01&date_to=2025-03-15
Authorization: Bearer {api_token}`,
    response: `HTTP/1.1 200 OK
Content-Type: application/json

{
  "agent_id": "salesx",
  "period": {
    "from": "2025-03-01T00:00:00Z",
    "to": "2025-03-15T23:59:59Z"
  },
  "metrics": {
    "events_processed": 3245,
    "success_rate": 0.94,
    "average_processing_time": 1.2,
    "leads_converted": 432
  },
  "top_events": [
    {
      "type": "new_lead",
      "count": 2103
    },
    {
      "type": "lead_qualified",
      "count": 876
    }
  ]
}`,
    authentication: true,
    params: [
      {
        name: 'agent_id',
        type: 'string',
        required: false,
        description: 'Filtrar por agente específico'
      },
      {
        name: 'pipeline_id',
        type: 'string',
        required: false,
        description: 'Filtrar por pipeline específico'
      },
      {
        name: 'date_from',
        type: 'string (ISO date)',
        required: false,
        description: 'Fecha inicial del periodo (formato YYYY-MM-DD)'
      },
      {
        name: 'date_to',
        type: 'string (ISO date)',
        required: false,
        description: 'Fecha final del periodo (formato YYYY-MM-DD)'
      }
    ]
  }
];

const ApiDocsPage: React.FC = () => {
  const [selectedMethod, setSelectedMethod] = useState<ApiMethod>(apiMethods[0]);
  const [copiedRequest, setCopiedRequest] = useState(false);
  const [copiedResponse, setCopiedResponse] = useState(false);
  
  // Update document title
  React.useEffect(() => {
    document.title = 'API Documentation - MELANO INC';
  }, []);
  
  const handleCopy = (text: string, setter: React.Dispatch<React.SetStateAction<boolean>>) => {
    navigator.clipboard.writeText(text).then(() => {
      setter(true);
      setTimeout(() => setter(false), 2000);
    });
  };

  const getMethodColor = (method: string) => {
    switch (method) {
      case 'GET': return 'bg-blue-100 text-blue-800';
      case 'POST': return 'bg-green-100 text-green-800';
      case 'PUT': return 'bg-yellow-100 text-yellow-800';
      case 'DELETE': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="pt-24 pb-16">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h1 className="mb-4">API Documentation</h1>
          <p className="text-xl">
            Integra fácilmente nuestros agentes IA en tu infraestructura existente
            utilizando nuestra API RESTful con documentación completa.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar Navigation */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-md p-6 sticky top-24">
              <h3 className="text-xl font-bold mb-4 flex items-center">
                <BookOpen size={20} className="mr-2 text-primary-600" />
                Endpoints
              </h3>
              <nav className="space-y-2">
                {apiMethods.map((method) => (
                  <button 
                    key={method.id}
                    onClick={() => setSelectedMethod(method)}
                    className={`w-full text-left py-2 px-3 rounded-lg transition-colors flex items-center ${
                      selectedMethod.id === method.id 
                        ? 'bg-primary-50 text-primary-700 font-medium' 
                        : 'hover:bg-gray-50'
                    }`}
                  >
                    <span className={`inline-block px-2 py-1 text-xs font-bold rounded mr-2 ${getMethodColor(method.method)}`}>
                      {method.method}
                    </span>
                    <span className="truncate">{method.title}</span>
                  </button>
                ))}
              </nav>
              
              <div className="mt-8 pt-4 border-t border-gray-100">
                <h4 className="font-medium text-gray-700 mb-3 flex items-center">
                  <Shield size={16} className="mr-2 text-primary-600" />
                  Authentication
                </h4>
                <p className="text-sm text-gray-600 mb-4">
                  All API requests require authentication via Bearer token in the Authorization header.
                </p>
                <code className="text-xs bg-gray-100 p-2 rounded block">
                  Authorization: Bearer {'{api_token}'}
                </code>
              </div>
            </div>
          </div>
          
          {/* Main Content */}
          <motion.div 
            key={selectedMethod.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="lg:col-span-3"
          >
            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              {/* Method Header */}
              <div className="border-b border-gray-200 bg-gray-50 px-6 py-4">
                <div className="flex flex-wrap items-center gap-3">
                  <span className={`px-3 py-1 rounded-full text-sm font-bold ${getMethodColor(selectedMethod.method)}`}>
                    {selectedMethod.method}
                  </span>
                  <span className="font-mono text-lg">{selectedMethod.url}</span>
                  {selectedMethod.authentication && (
                    <span className="ml-auto px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-xs flex items-center">
                      <Shield size={14} className="mr-1" />
                      Requiere autenticación
                    </span>
                  )}
                </div>
                <h2 className="text-2xl font-bold mt-3">{selectedMethod.title}</h2>
                <p className="text-gray-600 mt-1">{selectedMethod.description}</p>
              </div>
              
              {/* Method Content */}
              <div className="p-6">
                {/* Parameters */}
                {selectedMethod.params && (
                  <div className="mb-8">
                    <h3 className="text-xl font-bold mb-4 flex items-center">
                      <Database size={20} className="mr-2 text-primary-600" />
                      Parámetros
                    </h3>
                    <div className="overflow-x-auto">
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                          <tr>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Nombre
                            </th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Tipo
                            </th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Requerido
                            </th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Descripción
                            </th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          {selectedMethod.params.map((param, index) => (
                            <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                {param.name}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <code className="bg-gray-100 px-2 py-1 rounded text-xs">{param.type}</code>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {param.required ? (
                                  <span className="text-red-600 font-medium">Sí</span>
                                ) : (
                                  <span className="text-gray-500">No</span>
                                )}
                              </td>
                              <td className="px-6 py-4 text-sm text-gray-500">
                                {param.description}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
                
                {/* Request/Response Examples */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-xl font-bold mb-4 flex items-center">
                      <ArrowRight size={20} className="mr-2 text-primary-600" />
                      Request
                    </h3>
                    <div className="relative">
                      <SyntaxHighlighter 
                        language="http" 
                        style={tomorrow}
                        customStyle={{ borderRadius: '0.5rem' }}
                        className="syntax-highlighter"
                      >
                        {selectedMethod.request}
                      </SyntaxHighlighter>
                      <button 
                        className="absolute top-4 right-4 p-2 rounded-md hover:bg-gray-700 transition-colors"
                        onClick={() => handleCopy(selectedMethod.request, setCopiedRequest)}
                      >
                        {copiedRequest ? <Check size={18} className="text-green-400" /> : <Copy size={18} className="text-gray-400" />}
                      </button>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-xl font-bold mb-4 flex items-center">
                      <Server size={20} className="mr-2 text-primary-600" />
                      Response
                    </h3>
                    <div className="relative">
                      <SyntaxHighlighter 
                        language="http" 
                        style={tomorrow}
                        customStyle={{ borderRadius: '0.5rem' }}
                        className="syntax-highlighter"
                      >
                        {selectedMethod.response}
                      </SyntaxHighlighter>
                      <button 
                        className="absolute top-4 right-4 p-2 rounded-md hover:bg-gray-700 transition-colors"
                        onClick={() => handleCopy(selectedMethod.response, setCopiedResponse)}
                      >
                        {copiedResponse ? <Check size={18} className="text-green-400" /> : <Copy size={18} className="text-gray-400" />}
                      </button>
                    </div>
                  </div>
                </div>
                
                {/* Integration Notes */}
                <div className="mt-8 p-6 border border-primary-100 rounded-lg bg-primary-50">
                  <h3 className="text-xl font-bold mb-3 flex items-center">
                    <Code size={20} className="mr-2 text-primary-600" />
                    Notas de Integración
                  </h3>
                  <ul className="space-y-2 text-gray-700">
                    <li className="flex items-start">
                      <span className="text-primary-600 mr-2">•</span>
                      Todas las respuestas incluyen un código HTTP que indica el resultado de la operación.
                    </li>
                    <li className="flex items-start">
                      <span className="text-primary-600 mr-2">•</span>
                      Se recomienda implementar reintentos con backoff exponencial para manejar posibles errores temporales.
                    </li>
                    <li className="flex items-start">
                      <span className="text-primary-600 mr-2">•</span>
                      Los timestamps se devuelven en formato ISO 8601 (UTC).
                    </li>
                    <li className="flex items-start">
                      <span className="text-primary-600 mr-2">•</span>
                      Para entornos de producción, asegúrate de utilizar HTTPS para todas las solicitudes.
                    </li>
                  </ul>
                </div>
                
                {/* Rate Limits */}
                <div className="mt-6 p-6 border border-yellow-100 rounded-lg bg-yellow-50">
                  <h3 className="text-xl font-bold mb-3 flex items-center">
                    <Users size={20} className="mr-2 text-yellow-600" />
                    Límites de Uso
                  </h3>
                  <p className="mb-4">
                    La API aplica los siguientes límites de uso por token de API:
                  </p>
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-yellow-200">
                      <thead className="bg-yellow-100">
                        <tr>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-yellow-800 uppercase tracking-wider">
                            Plan
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-yellow-800 uppercase tracking-wider">
                            Peticiones / Minuto
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-yellow-800 uppercase tracking-wider">
                            Peticiones / Día
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-yellow-50 divide-y divide-yellow-200">
                        <tr>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            Desarrollo
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            60
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            10,000
                          </td>
                        </tr>
                        <tr>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            Producción
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            600
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            100,000
                          </td>
                        </tr>
                        <tr>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            Enterprise
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            3,000
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            Ilimitado
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              
              {/* Call to Action */}
              <div className="bg-gray-50 px-6 py-4 border-t border-gray-200">
                <div className="flex flex-wrap justify-between items-center gap-4">
                  <div>
                    <h4 className="font-bold">¿Necesitas ayuda con la integración?</h4>
                    <p className="text-sm text-gray-600">Nuestro equipo técnico está disponible para asistirte.</p>
                  </div>
                  <a href="#contacto" className="btn btn-primary">
                    Contactar Soporte
                  </a>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default ApiDocsPage;