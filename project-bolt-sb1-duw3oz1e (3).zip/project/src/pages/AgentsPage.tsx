import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { MessageSquare, BarChart2, FileText, Shield, User, Bot, Zap, Sparkles } from 'lucide-react';

interface AgentDetail {
  id: string;
  name: string;
  role: string;
  description: string;
  icon: React.ReactNode;
  color: string;
  capabilities: string[];
  useCases: string[];
  events: {
    type: string;
    description: string;
  }[];
}

const agentDetails: AgentDetail[] = [
  {
    id: 'sales-x',
    name: 'Agent.SalesX',
    role: 'Bot de ventas',
    description: 'Un agente conversacional avanzado que identifica, califica y convierte leads de forma autónoma. Utiliza procesamiento de lenguaje natural para entender las necesidades del cliente y ofrecer soluciones personalizadas.',
    icon: <MessageSquare size={28} />,
    color: 'bg-blue-50 text-blue-600 border-blue-200',
    capabilities: [
      'Conversaciones multiturno con memoria contextual',
      'Análisis de sentimiento e intención',
      'Personalización dinámica de respuestas',
      'Aprendizaje continuo basado en conversaciones previas',
      'Transferencia inteligente a agentes humanos cuando es necesario'
    ],
    useCases: [
      'Calificación y captación de leads',
      'Resolución de dudas sobre productos',
      'Asistencia en procesos de compra',
      'Seguimiento post-venta automatizado'
    ],
    events: [
      {
        type: 'new_lead',
        description: 'Se activa cuando un nuevo lead entra en el sistema'
      },
      {
        type: 'lead_qualified',
        description: 'Indica que un lead ha sido calificado como potencial cliente'
      },
      {
        type: 'conversation_completed',
        description: 'Se genera cuando una conversación concluye con un resultado específico'
      }
    ]
  },
  {
    id: 'invest-alpha',
    name: 'Agent.InvestAlpha',
    role: 'Bot de inversión',
    description: 'Este agente utiliza algoritmos avanzados de aprendizaje automático para analizar mercados financieros, detectar patrones y ejecutar estrategias de inversión con gestión automática de riesgos.',
    icon: <BarChart2 size={28} />,
    color: 'bg-green-50 text-green-600 border-green-200',
    capabilities: [
      'Análisis técnico y fundamental automatizado',
      'Modelado predictivo de precios de activos',
      'Detección de anomalías en mercados',
      'Optimización de carteras en tiempo real',
      'Backtesting y validación de estrategias'
    ],
    useCases: [
      'Trading algorítmico de alta frecuencia',
      'Gestión automatizada de carteras',
      'Detección de oportunidades de arbitraje',
      'Análisis de sentimiento de mercado'
    ],
    events: [
      {
        type: 'signal_trade',
        description: 'Señal de compra o venta generada por el análisis del mercado'
      },
      {
        type: 'risk_alert',
        description: 'Alerta de riesgo excesivo en operaciones actuales'
      },
      {
        type: 'portfolio_rebalance',
        description: 'Indicación para reequilibrar la cartera de inversiones'
      }
    ]
  },
  {
    id: 'ia-content',
    name: 'Agent.IAContent',
    role: 'Copy Generator',
    description: 'Un generador de contenido potenciado por IA que crea textos de alta calidad para múltiples canales. Produce contenido personalizado según el público objetivo y las necesidades específicas de comunicación.',
    icon: <FileText size={28} />,
    color: 'bg-purple-50 text-purple-600 border-purple-200',
    capabilities: [
      'Generación de textos en múltiples tonos y estilos',
      'Adaptación a directrices de marca',
      'Optimización automática para SEO',
      'Personalización basada en datos de audiencia',
      'Traducción y localización de contenido'
    ],
    useCases: [
      'Creación de artículos y posts para blog',
      'Redacción de emails para campañas de marketing',
      'Generación de descripciones de productos',
      'Creación de contenido para redes sociales'
    ],
    events: [
      {
        type: 'request_copy',
        description: 'Solicitud de generación de contenido con parámetros específicos'
      },
      {
        type: 'content_ready',
        description: 'Notificación de contenido generado y listo para revisión'
      },
      {
        type: 'revision_requested',
        description: 'Solicitud de modificación del contenido generado'
      }
    ]
  },
  {
    id: 'client-guard',
    name: 'Agent.ClientGuard',
    role: 'Soporte + Seguridad',
    description: 'Sistema de monitoreo y resolución proactiva de problemas que combina soporte al cliente con funciones de seguridad. Detecta y resuelve problemas antes de que afecten al usuario final.',
    icon: <Shield size={28} />,
    color: 'bg-red-50 text-red-600 border-red-200',
    capabilities: [
      'Monitoreo en tiempo real de sistemas',
      'Detección de anomalías y comportamientos sospechosos',
      'Resolución automática de problemas comunes',
      'Análisis de causas raíz',
      'Comunicación proactiva con usuarios afectados'
    ],
    useCases: [
      'Soporte técnico automatizado',
      'Prevención de fraudes y ataques',
      'Mantenimiento predictivo de sistemas',
      'Gestión de incidentes de seguridad'
    ],
    events: [
      {
        type: 'error_detected',
        description: 'Detección de un error o problema en el sistema'
      },
      {
        type: 'security_alert',
        description: 'Alerta de seguridad que requiere atención'
      },
      {
        type: 'issue_resolved',
        description: 'Confirmación de resolución de un problema detectado'
      }
    ]
  }
];

const AgentsPage: React.FC = () => {
  const [selectedAgent, setSelectedAgent] = useState<AgentDetail>(agentDetails[0]);

  // Update document title
  React.useEffect(() => {
    document.title = 'Agentes IA - MELANO INC';
  }, []);

  return (
    <div className="pt-24 pb-16">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h1 className="mb-4">Agentes IA</h1>
          <p className="text-xl">
            Conozca en detalle los agentes de inteligencia artificial que componen 
            nuestro ecosistema y sus capacidades específicas.
          </p>
        </div>
        
        {/* Agent Selection Tabs */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {agentDetails.map((agent) => (
            <button
              key={agent.id}
              onClick={() => setSelectedAgent(agent)}
              className={`px-4 py-3 rounded-lg flex items-center gap-2 transition-all ${
                selectedAgent.id === agent.id 
                  ? 'bg-primary-600 text-white shadow-lg' 
                  : 'bg-white border border-gray-200 hover:border-primary-300 hover:bg-primary-50'
              }`}
            >
              <div className={`p-2 rounded-lg ${
                selectedAgent.id === agent.id 
                  ? 'bg-primary-500' 
                  : agent.color.split(' ')[0]
              }`}>
                {agent.icon}
              </div>
              <span className="font-medium">{agent.name.split('.')[1]}</span>
            </button>
          ))}
        </div>
        
        {/* Agent Details */}
        <motion.div 
          key={selectedAgent.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="bg-white rounded-xl shadow-lg overflow-hidden"
        >
          <div className={`py-8 px-6 ${selectedAgent.color.split(' ')[0]}`}>
            <div className="flex flex-col md:flex-row md:items-center justify-between">
              <div className="flex items-center gap-4 mb-4 md:mb-0">
                <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center">
                  {selectedAgent.icon}
                </div>
                <div>
                  <h2 className="text-2xl font-bold">{selectedAgent.name}</h2>
                  <p className="text-lg font-medium">{selectedAgent.role}</p>
                </div>
              </div>
              <div className="flex gap-2">
                <span className="px-3 py-1 bg-white bg-opacity-20 backdrop-blur-sm rounded-full text-sm font-medium">
                  IA Avanzada
                </span>
                <span className="px-3 py-1 bg-white bg-opacity-20 backdrop-blur-sm rounded-full text-sm font-medium">
                  Autónomo
                </span>
              </div>
            </div>
          </div>
          
          <div className="p-6 md:p-8">
            <p className="text-lg mb-8">{selectedAgent.description}</p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="col-span-1">
                <div className="mb-6">
                  <h3 className="flex items-center gap-2 text-xl font-bold mb-4">
                    <Zap size={20} className="text-primary-600" />
                    Capacidades
                  </h3>
                  <ul className="space-y-2">
                    {selectedAgent.capabilities.map((capability, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <span className="text-primary-600 mt-1">•</span>
                        <span>{capability}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div>
                  <h3 className="flex items-center gap-2 text-xl font-bold mb-4">
                    <Sparkles size={20} className="text-primary-600" />
                    Casos de Uso
                  </h3>
                  <ul className="space-y-2">
                    {selectedAgent.useCases.map((useCase, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <span className="text-primary-600 mt-1">•</span>
                        <span>{useCase}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
              
              <div className="col-span-1 md:col-span-2">
                <h3 className="flex items-center gap-2 text-xl font-bold mb-4">
                  <Bot size={20} className="text-primary-600" />
                  Eventos Gestionados
                </h3>
                <div className="space-y-4">
                  {selectedAgent.events.map((event, index) => (
                    <div key={index} className="bg-gray-50 p-4 rounded-lg">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 mb-2">
                        <code className="font-mono text-sm bg-gray-200 px-2 py-1 rounded">
                          {event.type}
                        </code>
                        <div className="flex items-center gap-2">
                          <User size={16} className="text-gray-500" />
                          <span className="text-sm text-gray-600">Requiere autenticación</span>
                        </div>
                      </div>
                      <p className="text-gray-700">{event.description}</p>
                    </div>
                  ))}
                </div>
                
                <div className="mt-8 p-6 border border-primary-100 rounded-lg bg-primary-50">
                  <h4 className="text-lg font-bold mb-3">Integración con Melania.Core</h4>
                  <p className="mb-4">
                    Este agente se comunica con el orquestador central a través de eventos asíncronos, 
                    permitiendo una operación coordinada con otros agentes del ecosistema.
                  </p>
                  <div className="flex justify-end">
                    <a href="/api" className="btn btn-primary">
                      Ver Documentación API
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default AgentsPage;