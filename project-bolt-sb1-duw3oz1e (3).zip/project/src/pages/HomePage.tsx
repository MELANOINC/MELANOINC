import React from 'react';
import Hero from '../components/Hero';
import Architecture from '../components/Architecture';
import AgentList from '../components/AgentList';
import ApiExample from '../components/ApiExample';
import FutureExtensions from '../components/FutureExtensions';

const HomePage: React.FC = () => {
  // Update document title
  React.useEffect(() => {
    document.title = 'MELANO INC - Sistema de Agentes IA Autónomos';
  }, []);

  return (
    <>
      <Hero />
      <Architecture />
      <AgentList />
      <ApiExample />
      <FutureExtensions />
    </>
  );
};

export default HomePage;