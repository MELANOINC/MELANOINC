import React, { useState } from 'react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { tomorrow } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { Terminal, Copy, Check } from 'lucide-react';

const installCode = `git clone https://github.com/melano-inc/ia-agents.git
cd ia-agents
pip install fastapi uvicorn`;

const runCode = `uvicorn main:app --reload`;

const apiExampleCode = `POST /evento
{
  "id": "1234",
  "source": "SalesX",
  "type": "new_lead",
  "payload": {
    "lead_name": "Juan Pérez"
  }
}`;

const securityCode = `// Tokens JWT con Auth0
// Validación de origen por IP o API Key
// Log + auditoría para trazabilidad`;

const ApiExample: React.FC = () => {
  const [copiedInstall, setCopiedInstall] = useState(false);
  const [copiedRun, setCopiedRun] = useState(false);
  const [copiedApi, setCopiedApi] = useState(false);
  
  const handleCopy = (text: string, setter: React.Dispatch<React.SetStateAction<boolean>>) => {
    navigator.clipboard.writeText(text).then(() => {
      setter(true);
      setTimeout(() => setter(false), 2000);
    });
  };

  return (
    <section className="section bg-gray-50">
      <div className="container">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="mb-4">API y Documentación</h2>
          <p className="text-xl">
            Integra fácilmente nuestros agentes IA en tu infraestructura existente
            utilizando nuestra API RESTful.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          <div>
            <h3 className="flex items-center mb-6">
              <Terminal size={24} className="mr-2 text-primary-600" />
              Instalación
            </h3>
            <div className="relative mb-8">
              <SyntaxHighlighter 
                language="bash" 
                style={tomorrow}
                customStyle={{ borderRadius: '0.5rem' }}
                className="syntax-highlighter"
              >
                {installCode}
              </SyntaxHighlighter>
              <button 
                className="absolute top-4 right-4 p-2 rounded-md hover:bg-gray-700 transition-colors"
                onClick={() => handleCopy(installCode, setCopiedInstall)}
              >
                {copiedInstall ? <Check size={18} className="text-green-400" /> : <Copy size={18} className="text-gray-400" />}
              </button>
            </div>
            
            <h3 className="flex items-center mb-6">
              <Terminal size={24} className="mr-2 text-primary-600" />
              Ejecución
            </h3>
            <div className="relative mb-8">
              <SyntaxHighlighter 
                language="bash" 
                style={tomorrow}
                customStyle={{ borderRadius: '0.5rem' }}
                className="syntax-highlighter"
              >
                {runCode}
              </SyntaxHighlighter>
              <button 
                className="absolute top-4 right-4 p-2 rounded-md hover:bg-gray-700 transition-colors"
                onClick={() => handleCopy(runCode, setCopiedRun)}
              >
                {copiedRun ? <Check size={18} className="text-green-400" /> : <Copy size={18} className="text-gray-400" />}
              </button>
            </div>
            
            <div className="p-4 bg-white rounded-lg shadow-md">
              <p className="text-primary-800 font-medium">
                API activa en: <a href="http://localhost:8000/docs" className="text-primary-600 hover:underline">http://localhost:8000/docs</a>
              </p>
            </div>
          </div>
          
          <div>
            <h3 className="flex items-center mb-6">
              <Terminal size={24} className="mr-2 text-primary-600" />
              Ejemplo de Evento
            </h3>
            <div className="relative mb-8">
              <SyntaxHighlighter 
                language="json" 
                style={tomorrow}
                customStyle={{ borderRadius: '0.5rem' }}
                className="syntax-highlighter"
              >
                {apiExampleCode}
              </SyntaxHighlighter>
              <button 
                className="absolute top-4 right-4 p-2 rounded-md hover:bg-gray-700 transition-colors"
                onClick={() => handleCopy(apiExampleCode, setCopiedApi)}
              >
                {copiedApi ? <Check size={18} className="text-green-400" /> : <Copy size={18} className="text-gray-400" />}
              </button>
            </div>
            
            <h3 className="flex items-center mb-6">
              <Terminal size={24} className="mr-2 text-primary-600" />
              Seguridad Recomendada
            </h3>
            <SyntaxHighlighter 
              language="javascript" 
              style={tomorrow}
              customStyle={{ borderRadius: '0.5rem' }}
              className="syntax-highlighter"
            >
              {securityCode}
            </SyntaxHighlighter>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ApiExample;