import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import { Menu, X, Brain, BarChart2, Terminal } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header 
      className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4">
        <nav className="flex justify-between items-center">
          <NavLink to="/" className="flex items-center space-x-2 font-bold text-xl text-primary-900">
            <Brain size={28} className="text-primary-600" />
            <span>MELANO INC</span>
          </NavLink>
          
          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-8">
            <NavLink 
              to="/" 
              className={({isActive}) => 
                `font-medium hover:text-primary-600 transition-colors ${isActive ? 'text-primary-600' : 'text-gray-700'}`
              }
            >
              Inicio
            </NavLink>
            <NavLink 
              to="/agentes" 
              className={({isActive}) => 
                `font-medium hover:text-primary-600 transition-colors ${isActive ? 'text-primary-600' : 'text-gray-700'}`
              }
            >
              Agentes IA
            </NavLink>
            <NavLink 
              to="/api" 
              className={({isActive}) => 
                `font-medium hover:text-primary-600 transition-colors ${isActive ? 'text-primary-600' : 'text-gray-700'}`
              }
            >
              API
            </NavLink>
            <a 
              href="#contacto" 
              className="btn btn-primary"
            >
              Contacto
            </a>
          </div>
          
          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-gray-800"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </nav>
        
        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-white mt-2 py-4 px-2 rounded-lg shadow-lg">
            <div className="flex flex-col space-y-4">
              <NavLink 
                to="/" 
                className={({isActive}) => 
                  `font-medium px-4 py-2 rounded hover:bg-primary-50 ${isActive ? 'text-primary-600 bg-primary-50' : 'text-gray-700'}`
                }
                onClick={() => setIsMenuOpen(false)}
              >
                Inicio
              </NavLink>
              <NavLink 
                to="/agentes" 
                className={({isActive}) => 
                  `font-medium px-4 py-2 rounded hover:bg-primary-50 ${isActive ? 'text-primary-600 bg-primary-50' : 'text-gray-700'}`
                }
                onClick={() => setIsMenuOpen(false)}
              >
                Agentes IA
              </NavLink>
              <NavLink 
                to="/api" 
                className={({isActive}) => 
                  `font-medium px-4 py-2 rounded hover:bg-primary-50 ${isActive ? 'text-primary-600 bg-primary-50' : 'text-gray-700'}`
                }
                onClick={() => setIsMenuOpen(false)}
              >
                API
              </NavLink>
              <a 
                href="#contacto" 
                className="btn btn-primary mx-4"
                onClick={() => setIsMenuOpen(false)}
              >
                Contacto
              </a>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Navbar;