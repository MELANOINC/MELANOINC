import React from 'react';
import { motion } from 'framer-motion';
import { DatabaseIcon, BarChart, Braces, ArrowRight } from 'lucide-react';

const extensions = [
  {
    id: 'crm',
    title: 'Conexión con CRMs reales',
    description: 'Integración directa con HubSpot, Pipedrive y otros CRMs populares para sincronización automática de leads y oportunidades.',
    icon: <DatabaseIcon size={32} />,
    color: 'bg-blue-50 text-blue-600 border-blue-200',
  },
  {
    id: 'trading',
    title: 'Ejecución de trades reales',
    description: 'Conexión con API de Binance para implementar estrategias de trading automatizadas con gestión de riesgo personalizable.',
    icon: <BarChart size={32} />,
    color: 'bg-green-50 text-green-600 border-green-200',
  },
  {
    id: 'ai',
    title: 'Modelos avanzados de IA',
    description: 'Implementación de OpenAI o modelos propios para mejorar la generación de contenido y las capacidades de procesamiento de lenguaje natural.',
    icon: <Braces size={32} />,
    color: 'bg-purple-50 text-purple-600 border-purple-200',
  },
  {
    id: 'events',
    title: 'Sistema de eventos distribuidos',
    description: 'Integración con Kafka o Redis Streams para manejo escalable de eventos y comunicación asíncrona entre agentes.',
    icon: <ArrowRight size={32} />,
    color: 'bg-red-50 text-red-600 border-red-200',
  },
];

const FutureExtensions: React.FC = () => {
  return (
    <section className="section">
      <div className="container">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="mb-4">Futuras Extensiones</h2>
          <p className="text-xl">
            Nuestra plataforma evoluciona constantemente. Estas son algunas de las 
            próximas funcionalidades que implementaremos.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {extensions.map((extension, index) => (
            <motion.div 
              key={extension.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className={`card border-2 ${extension.color}`}
            >
              <div className="flex items-start gap-4">
                <div className={`p-3 rounded-lg ${extension.color}`}>
                  {extension.icon}
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">{extension.title}</h3>
                  <p className="text-gray-600">{extension.description}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <a href="#contacto" className="btn btn-primary">
            Solicitar Información
          </a>
        </div>
      </div>
    </section>
  );
};

export default FutureExtensions;