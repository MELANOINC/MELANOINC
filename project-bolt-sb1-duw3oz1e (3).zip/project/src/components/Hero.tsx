import React, { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Brain, ChevronDown } from 'lucide-react';

const Hero: React.FC = () => {
  const particlesRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    if (!particlesRef.current) return;
    
    const createParticles = () => {
      const container = particlesRef.current;
      if (!container) return;
      
      // Clear existing particles
      container.innerHTML = '';
      
      const particleCount = 50;
      const colors = ['#3f67e6', '#7c5bf4', '#d946ef'];
      
      for (let i = 0; i < particleCount; i++) {
        const particle = document.createElement('div');
        particle.classList.add('particle');
        
        // Random position
        const x = Math.random() * 100;
        const y = Math.random() * 100;
        
        // Random size
        const size = Math.random() * 4 + 1;
        
        // Random color
        const color = colors[Math.floor(Math.random() * colors.length)];
        
        // Random opacity
        const opacity = Math.random() * 0.5 + 0.3;
        
        // Set styles
        particle.style.left = `${x}%`;
        particle.style.top = `${y}%`;
        particle.style.width = `${size}px`;
        particle.style.height = `${size}px`;
        particle.style.backgroundColor = color;
        particle.style.opacity = opacity.toString();
        
        // Animate
        particle.style.animation = `float ${Math.random() * 10 + 5}s ease-in-out infinite`;
        particle.style.animationDelay = `${Math.random() * 5}s`;
        
        container.appendChild(particle);
      }
    };
    
    createParticles();
    
    window.addEventListener('resize', createParticles);
    return () => {
      window.removeEventListener('resize', createParticles);
    };
  }, []);

  return (
    <section className="relative pt-32 pb-20 md:pt-40 md:pb-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-primary-50 to-white z-0"></div>
      <div ref={particlesRef} className="particles"></div>
      
      <div className="container relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-6"
          >
            <Brain size={72} className="mx-auto text-primary-600" />
          </motion.div>
          
          <motion.h1 
            className="mb-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <span className="gradient-text">MELANO INC</span>
            <br />
            <span className="text-gray-900">Sistema de Agentes IA Autónomos</span>
          </motion.h1>
          
          <motion.p 
            className="text-xl md:text-2xl text-gray-600 mb-10 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            Un ecosistema de agentes de inteligencia artificial interconectados que automatizan inversiones, 
            ventas, generación de contenido y soporte.
          </motion.p>
          
          <motion.div 
            className="flex flex-col sm:flex-row justify-center gap-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
          >
            <a href="#arquitectura" className="btn btn-primary">
              Descubrir Plataforma
            </a>
            <a href="#agentes" className="btn btn-outline">
              Ver Agentes IA
            </a>
          </motion.div>
        </div>
        
        <motion.div 
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2 hidden md:block"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1, repeat: Infinity, repeatType: "reverse" }}
        >
          <a href="#arquitectura" className="text-primary-600">
            <ChevronDown size={32} />
          </a>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;