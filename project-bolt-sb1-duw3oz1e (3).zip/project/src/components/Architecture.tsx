import React from 'react';
import { motion } from 'framer-motion';
import { Brain, BarChart2, MessageSquare, FileText, Shield } from 'lucide-react';

const Architecture: React.FC = () => {
  return (
    <section className="section bg-gray-50" id="arquitectura">
      <div className="container">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="mb-4">Arquitectura</h2>
          <p className="text-xl">
            La plataforma MELANO INC está compuesta por un orquestador central y cuatro agentes especializados
            que trabajan de forma coordinada para ofrecer soluciones completas.
          </p>
        </div>
        
        <div className="relative">
          {/* Main Architecture Diagram */}
          <div className="relative z-10 max-w-4xl mx-auto">
            {/* Core */}
            <motion.div 
              initial={{ y: 20, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="card bg-primary-600 text-white mb-16 mx-auto max-w-md"
            >
              <div className="text-center">
                <Brain size={48} className="mx-auto mb-4" />
                <h3 className="text-white mb-2">Melania.Core</h3>
                <p className="text-primary-100">(Orquestador IA)</p>
              </div>
            </motion.div>
            
            {/* Connection Line */}
            <div className="absolute top-[5.5rem] left-1/2 w-0.5 h-16 bg-primary-300 transform -translate-x-1/2"></div>
            
            {/* Horizontal Line */}
            <div className="absolute top-[13.5rem] left-1/4 right-1/4 h-0.5 bg-primary-300"></div>
            
            {/* Vertical Lines */}
            <div className="absolute top-[13.5rem] left-1/4 w-0.5 h-16 bg-primary-300"></div>
            <div className="absolute top-[13.5rem] left-1/2 w-0.5 h-16 bg-primary-300 transform -translate-x-1/2"></div>
            <div className="absolute top-[13.5rem] left-3/4 w-0.5 h-16 bg-primary-300"></div>
            <div className="absolute top-[13.5rem] right-1/4 w-0.5 h-16 bg-primary-300 transform translate-x-1/2"></div>
            
            {/* Agents */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 relative z-10 mt-24">
              <motion.div 
                initial={{ y: 20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="card"
              >
                <div className="text-center">
                  <div className="w-16 h-16 rounded-full bg-secondary-100 flex items-center justify-center mx-auto mb-4">
                    <MessageSquare size={28} className="text-secondary-600" />
                  </div>
                  <h4 className="mb-2">Agent.SalesX</h4>
                  <p className="text-sm text-gray-600">Bot de ventas</p>
                </div>
              </motion.div>
              
              <motion.div 
                initial={{ y: 20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.3 }}
                className="card"
              >
                <div className="text-center">
                  <div className="w-16 h-16 rounded-full bg-secondary-100 flex items-center justify-center mx-auto mb-4">
                    <BarChart2 size={28} className="text-secondary-600" />
                  </div>
                  <h4 className="mb-2">Agent.InvestAlpha</h4>
                  <p className="text-sm text-gray-600">Bot de inversión</p>
                </div>
              </motion.div>
              
              <motion.div 
                initial={{ y: 20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.4 }}
                className="card"
              >
                <div className="text-center">
                  <div className="w-16 h-16 rounded-full bg-secondary-100 flex items-center justify-center mx-auto mb-4">
                    <FileText size={28} className="text-secondary-600" />
                  </div>
                  <h4 className="mb-2">Agent.IAContent</h4>
                  <p className="text-sm text-gray-600">Copy Generator</p>
                </div>
              </motion.div>
              
              <motion.div 
                initial={{ y: 20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.5 }}
                className="card"
              >
                <div className="text-center">
                  <div className="w-16 h-16 rounded-full bg-secondary-100 flex items-center justify-center mx-auto mb-4">
                    <Shield size={28} className="text-secondary-600" />
                  </div>
                  <h4 className="mb-2">Agent.ClientGuard</h4>
                  <p className="text-sm text-gray-600">Soporte + Seguridad</p>
                </div>
              </motion.div>
            </div>
          </div>
          
          {/* Background elements */}
          <div className="absolute top-1/2 left-1/2 w-96 h-96 bg-primary-100 rounded-full opacity-20 transform -translate-x-1/2 -translate-y-1/2 blur-3xl"></div>
          <div className="absolute top-1/3 right-1/4 w-64 h-64 bg-secondary-100 rounded-full opacity-30 blur-3xl"></div>
          <div className="absolute bottom-1/4 left-1/3 w-72 h-72 bg-accent-100 rounded-full opacity-30 blur-3xl"></div>
        </div>
      </div>
    </section>
  );
};

export default Architecture;