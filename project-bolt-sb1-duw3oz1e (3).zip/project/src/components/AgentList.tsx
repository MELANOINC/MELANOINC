import React from 'react';
import { motion } from 'framer-motion';
import { MessageSquare, BarChart2, FileText, Shield } from 'lucide-react';

interface Agent {
  id: string;
  name: string;
  role: string;
  description: string;
  eventType: string;
  icon: React.ReactNode;
  color: string;
}

const agents: Agent[] = [
  {
    id: 'sales-x',
    name: 'Agent.SalesX',
    role: 'Captación y conversión de leads',
    description: 'Nuestro bot de ventas utiliza IA avanzada para interactuar con potenciales clientes, calificarlos y guiarlos a través del embudo de conversión con respuestas personalizadas y seguimiento automatizado.',
    eventType: 'new_lead',
    icon: <MessageSquare size={28} />,
    color: 'bg-blue-50 text-blue-600',
  },
  {
    id: 'invest-alpha',
    name: 'Agent.InvestAlpha',
    role: 'Ejecución de estrategias de trading IA',
    description: 'Este agente analiza continuamente mercados financieros utilizando modelos predictivos avanzados para identificar oportunidades de inversión y ejecutar operaciones con gestión de riesgo automatizada.',
    eventType: 'signal_trade',
    icon: <BarChart2 size={28} />,
    color: 'bg-green-50 text-green-600',
  },
  {
    id: 'ia-content',
    name: 'Agent.IAContent',
    role: 'Generación de contenido automatizado',
    description: 'Nuestro generador de contenido crea automáticamente textos optimizados para SEO, publicaciones para redes sociales, correos electrónicos personalizados y material de marketing adaptado a su audiencia.',
    eventType: 'request_copy',
    icon: <FileText size={28} />,
    color: 'bg-purple-50 text-purple-600',
  },
  {
    id: 'client-guard',
    name: 'Agent.ClientGuard',
    role: 'Monitoreo y solución de errores',
    description: 'Este agente monitoriza la plataforma en tiempo real, detecta y resuelve problemas de forma proactiva, y proporciona soporte instantáneo a usuarios mediante chat inteligente con capacidades de autodiagnóstico.',
    eventType: 'error_detected',
    icon: <Shield size={28} />,
    color: 'bg-red-50 text-red-600',
  },
];

const AgentList: React.FC = () => {
  return (
    <section className="section" id="agentes">
      <div className="container">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="mb-4">Agentes Implementados</h2>
          <p className="text-xl">
            Cada agente está especializado en un dominio específico y funciona de manera 
            autónoma, comunicándose con el sistema central para proporcionar soluciones integrales.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {agents.map((agent, index) => (
            <motion.div 
              key={agent.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="card hover:translate-y-[-5px]"
            >
              <div className={`w-16 h-16 rounded-full ${agent.color} flex items-center justify-center mb-6`}>
                {agent.icon}
              </div>
              <h3 className="text-2xl font-bold mb-2">{agent.name}</h3>
              <p className="text-lg font-medium text-primary-600 mb-3">{agent.role}</p>
              <p className="text-gray-600 mb-4">{agent.description}</p>
              <div className="bg-gray-100 px-4 py-2 rounded-lg inline-block">
                <code className="text-sm font-mono">Tipo de Evento: {agent.eventType}</code>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AgentList;