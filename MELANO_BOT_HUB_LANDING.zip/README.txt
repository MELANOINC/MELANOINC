MELANO BOT HUB - Landing Funcional

✔ Subilo directo a Netlify o Hostinger
✔ Editá el index.html si querés personalizar texto o links
✔ Contacto directo activado con tu WhatsApp
✔ Ideal para mostrar como demo o versión MVP

Hecho para Bruno Melano - CEO MELANO INC