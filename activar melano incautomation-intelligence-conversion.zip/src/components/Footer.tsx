import { Button } from "@/components/ui/button";
import { MessageCircle, Mail, Phone, MapPin, ExternalLink } from "lucide-react";

const Footer = () => {
  const handleWhatsAppClick = () => {
    const message = encodeURIComponent("Hola Melania! Quiero más información sobre MELANO INC");
    window.open(`https://wa.me/5492235506585?text=${message}`, '_blank');
  };

  const handleEmailClick = () => {
    window.open('mailto:contacto@brunomelano.com', '_blank');
  };

  const handleWebsiteClick = () => {
    window.open('https://brunomelano.com', '_blank');
  };

  const handleMelanoBotClick = () => {
    window.open('https://melanobothub.ai', '_blank');
  };

  return (
    <footer className="bg-slate-900 text-white py-16">
      <div className="container mx-auto px-4">
        {/* Main Footer Content */}
        <div className="grid md:grid-cols-4 gap-8 mb-12">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center mb-6">
              <div className="w-8 h-8 bg-gradient-to-br from-teal-400 to-teal-600 transform rotate-45 mr-3"></div>
              <h3 className="text-2xl font-bold bg-gradient-to-r from-amber-200 to-amber-400 bg-clip-text text-transparent">
                MELANO INC
              </h3>
            </div>
            <p className="text-gray-300 mb-6 max-w-md">
              Sistemas que convierten, aunque vos estés durmiendo. 
              Plataforma de inversión y ventas automatizadas con inteligencia artificial.
            </p>
            <Button 
              onClick={handleWhatsAppClick}
              className="bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600 text-white"
            >
              <MessageCircle className="mr-2 w-4 h-4" />
              Hablá con Melania
            </Button>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-amber-200">Servicios</h4>
            <ul className="space-y-2 text-gray-300">
              <li>
                <button 
                  onClick={handleWhatsAppClick}
                  className="hover:text-teal-400 transition-colors text-left"
                >
                  Bots de Inversión
                </button>
              </li>
              <li>
                <button 
                  onClick={handleWhatsAppClick}
                  className="hover:text-teal-400 transition-colors text-left"
                >
                  Ventas Automatizadas
                </button>
              </li>
              <li>
                <button 
                  onClick={handleWhatsAppClick}
                  className="hover:text-teal-400 transition-colors text-left"
                >
                  Real Estate IA
                </button>
              </li>
              <li>
                <button 
                  onClick={handleWhatsAppClick}
                  className="hover:text-teal-400 transition-colors text-left"
                >
                  Consultoría Premium
                </button>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-amber-200">Contacto</h4>
            <div className="space-y-3 text-gray-300">
              <button 
                onClick={handleWhatsAppClick}
                className="flex items-center space-x-2 hover:text-teal-400 transition-colors"
              >
                <MessageCircle className="w-4 h-4 text-teal-400" />
                <span>WhatsApp: +54 9 223 5 506585</span>
              </button>
              <button 
                onClick={handleEmailClick}
                className="flex items-center space-x-2 hover:text-teal-400 transition-colors"
              >
                <Mail className="w-4 h-4 text-teal-400" />
                <span>contacto@brunomelano.com</span>
              </button>
              <button 
                onClick={handleWebsiteClick}
                className="flex items-center space-x-2 hover:text-teal-400 transition-colors"
              >
                <ExternalLink className="w-4 h-4 text-teal-400" />
                <span>brunomelano.com</span>
              </button>
              <button 
                onClick={handleMelanoBotClick}
                className="flex items-center space-x-2 hover:text-teal-400 transition-colors"
              >
                <ExternalLink className="w-4 h-4 text-teal-400" />
                <span>melanobothub.ai</span>
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-slate-700 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-gray-400 text-sm">
              © 2024 MELANO INC. Todos los derechos reservados.
            </div>
            <div className="flex space-x-6 text-sm text-gray-400">
              <button 
                onClick={handleWhatsAppClick}
                className="hover:text-teal-400 transition-colors"
              >
                Términos de Servicio
              </button>
              <button 
                onClick={handleWhatsAppClick}
                className="hover:text-teal-400 transition-colors"
              >
                Política de Privacidad
              </button>
              <button 
                onClick={handleWhatsAppClick}
                className="hover:text-teal-400 transition-colors"
              >
                Disclaimer
              </button>
            </div>
          </div>
        </div>

        {/* Final CTA */}
        <div className="mt-8 text-center p-6 bg-gradient-to-r from-slate-800 to-slate-700 rounded-lg border border-slate-600">
          <p className="text-amber-300 font-semibold mb-2">
            🚀 ¿Listo para activar tu máquina de ingresos?
          </p>
          <p className="text-gray-300 text-sm mb-4">
            Solo quedan pocas activaciones gratuitas esta semana
          </p>
          <Button 
            onClick={handleWhatsAppClick}
            className="bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600 text-white"
          >
            <MessageCircle className="mr-2 w-4 h-4" />
            Contactar ahora
          </Button>
        </div>
      </div>
    </footer>
  );
};

export default Footer;