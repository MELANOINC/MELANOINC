import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { TrendingUp, Users, DollarSign, Activity, ArrowUp, ArrowDown } from "lucide-react";

const Dashboard = () => {
  const metrics = [
    {
      title: "Leads Generados",
      value: "127",
      change: "+23%",
      trend: "up",
      icon: Users,
      color: "text-blue-600"
    },
    {
      title: "Conversiones",
      value: "34",
      change: "+45%",
      trend: "up",
      icon: TrendingUp,
      color: "text-emerald-600"
    },
    {
      title: "Ingresos Generados",
      value: "$12,450",
      change: "+67%",
      trend: "up",
      icon: DollarSign,
      color: "text-green-600"
    },
    {
      title: "Bots Activos",
      value: "8",
      change: "+2",
      trend: "up",
      icon: Activity,
      color: "text-purple-600"
    }
  ];

  const conversionFunnel = [
    { stage: "Visitantes", count: 1250, percentage: 100 },
    { stage: "Leads", count: 127, percentage: 10.2 },
    { stage: "Qualified", count: 68, percentage: 5.4 },
    { stage: "Conversiones", count: 34, percentage: 2.7 }
  ];

  return (
    <div className="p-6 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">
            Dashboard MELANO INC
          </h1>
          <p className="text-slate-600">
            Métricas en tiempo real de tu máquina de conversión
          </p>
        </div>

        {/* KPI Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          {metrics.map((metric, index) => {
            const IconComponent = metric.icon;
            return (
              <Card key={index} className="p-6 bg-white border-0 shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <IconComponent className={`w-8 h-8 ${metric.color}`} />
                  <Badge 
                    variant={metric.trend === 'up' ? 'default' : 'destructive'}
                    className={metric.trend === 'up' ? 'bg-emerald-100 text-emerald-700' : ''}
                  >
                    {metric.trend === 'up' ? <ArrowUp className="w-3 h-3 mr-1" /> : <ArrowDown className="w-3 h-3 mr-1" />}
                    {metric.change}
                  </Badge>
                </div>
                <div className="text-2xl font-bold text-slate-900 mb-1">
                  {metric.value}
                </div>
                <div className="text-sm text-slate-600">
                  {metric.title}
                </div>
              </Card>
            );
          })}
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Conversion Funnel */}
          <Card className="p-6 bg-white border-0 shadow-sm">
            <h3 className="text-lg font-semibold text-slate-900 mb-6">
              Embudo de Conversión
            </h3>
            <div className="space-y-4">
              {conversionFunnel.map((stage, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-slate-700">
                      {stage.stage}
                    </span>
                    <span className="text-sm text-slate-600">
                      {stage.count} ({stage.percentage}%)
                    </span>
                  </div>
                  <Progress value={stage.percentage} className="h-2" />
                </div>
              ))}
            </div>
          </Card>

          {/* Revenue per Lead */}
          <Card className="p-6 bg-white border-0 shadow-sm">
            <h3 className="text-lg font-semibold text-slate-900 mb-6">
              KPI Crítico: $ por Lead
            </h3>
            <div className="text-center">
              <div className="text-4xl font-bold text-emerald-600 mb-2">
                $98
              </div>
              <div className="text-sm text-slate-600 mb-4">
                Ingresos promedio por lead generado
              </div>
              <Badge className="bg-emerald-100 text-emerald-700">
                <ArrowUp className="w-3 h-3 mr-1" />
                +15% vs mes anterior
              </Badge>
            </div>
            
            <div className="mt-6 pt-6 border-t border-slate-200">
              <div className="grid grid-cols-2 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-slate-900">26.8%</div>
                  <div className="text-xs text-slate-600">Tasa de conversión</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-slate-900">$366</div>
                  <div className="text-xs text-slate-600">Valor promedio cliente</div>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;