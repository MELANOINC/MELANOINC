import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight, Bot, TrendingUp, Zap } from "lucide-react";

const Hero = () => {
  const handleWhatsAppClick = () => {
    const message = encodeURIComponent("Hola! Quiero hablar con Melania sobre los bots de MELANO INC");
    window.open(`https://wa.me/5492235506585?text=${message}`, '_blank');
  };

  return (
    <section className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 opacity-20" style={{
        backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.03'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
      }}></div>
      
      <div className="container mx-auto px-4 py-20 relative z-10">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center mb-6">
            <div className="w-12 h-12 bg-gradient-to-br from-teal-400 to-teal-600 transform rotate-45 mr-4"></div>
            <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-amber-200 to-amber-400 bg-clip-text text-transparent">
              MELANO INC
            </h1>
          </div>
          <p className="text-xl md:text-2xl text-amber-200 font-light mb-4">
            SISTEMAS QUE CONVIERTEN,
          </p>
          <p className="text-xl md:text-2xl text-amber-200 font-light">
            AUNQUE VOS ESTÉS DURMIENDO
          </p>
        </div>

        {/* Main CTA */}
        <div className="max-w-4xl mx-auto text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold mb-6 leading-tight">
            ¿Querés bots que te generen
            <span className="bg-gradient-to-r from-teal-400 to-emerald-400 bg-clip-text text-transparent"> ingresos </span>
            mientras dormís?
          </h2>
          <p className="text-lg md:text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Accedé gratis a tu primera estrategia automatizada con Melania IA. 
            Resultados reales, en tiempo real.
          </p>
          
          <Card className="bg-slate-800/50 border-slate-700 p-8 backdrop-blur-sm">
            <div className="grid md:grid-cols-3 gap-6 mb-8">
              <div className="text-center">
                <Bot className="w-12 h-12 text-teal-400 mx-auto mb-3" />
                <h3 className="font-semibold text-white mb-2">Bots de Inversión</h3>
                <p className="text-sm text-gray-400">Scalping, arbitraje, tendencias</p>
              </div>
              <div className="text-center">
                <TrendingUp className="w-12 h-12 text-emerald-400 mx-auto mb-3" />
                <h3 className="font-semibold text-white mb-2">Ventas Automatizadas</h3>
                <p className="text-sm text-gray-400">Real estate y high-ticket</p>
              </div>
              <div className="text-center">
                <Zap className="w-12 h-12 text-amber-400 mx-auto mb-3" />
                <h3 className="font-semibold text-white mb-2">IA que Aprende</h3>
                <p className="text-sm text-gray-400">Mejora con cada dato</p>
              </div>
            </div>
            
            <Button 
              onClick={handleWhatsAppClick}
              size="lg" 
              className="bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600 text-white font-semibold px-8 py-4 text-lg group"
            >
              Hablá con Melania
              <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
          </Card>
        </div>

        {/* Urgency */}
        <div className="text-center">
          <p className="text-amber-300 font-semibold text-lg">
            🔥 Solo 30 activaciones gratuitas esta semana
          </p>
        </div>
      </div>
    </section>
  );
};

export default Hero;