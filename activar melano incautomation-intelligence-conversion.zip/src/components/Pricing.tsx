import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, Star, Zap } from "lucide-react";

const Pricing = () => {
  const handleActivateClick = () => {
    const message = encodeURIComponent(
      "Hola Melania! Quiero activar mi membresía MELANO STARTER gratis por 7 días. ¿Podemos empezar ahora?"
    );
    window.open(`https://wa.me/5492235506585?text=${message}`, '_blank');
  };

  return (
    <section className="py-20 bg-gradient-to-br from-slate-900 to-slate-800 text-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Membresía
            <span className="bg-gradient-to-r from-amber-400 to-amber-200 bg-clip-text text-transparent"> MELANO STARTER</span>
          </h2>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            Activación inmediata de tu primer bot con acceso completo al ecosistema MELANO INC
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <Card className="bg-gradient-to-br from-slate-800 to-slate-700 border-slate-600 p-8 relative overflow-hidden">
            {/* Premium Badge */}
            <div className="absolute top-4 right-4">
              <Badge className="bg-gradient-to-r from-amber-500 to-amber-400 text-slate-900 font-semibold">
                <Star className="w-4 h-4 mr-1" />
                PREMIUM
              </Badge>
            </div>

            <div className="grid md:grid-cols-2 gap-8 items-center">
              {/* Left: Features */}
              <div>
                <h3 className="text-2xl font-bold text-white mb-6">
                  Lo que incluye tu membresía:
                </h3>
                
                <div className="space-y-4">
                  {[
                    "Activación inmediata de 1 bot de inversión",
                    "Acceso al panel de rendimiento en tiempo real",
                    "Video de onboarding personal con Bruno",
                    "Soporte prioritario con Melania IA",
                    "Estrategias de scalping y arbitraje",
                    "Alertas y notificaciones automáticas",
                    "Backup y seguridad de fondos",
                    "Acceso a la comunidad MELANO"
                  ].map((feature, index) => (
                    <div key={index} className="flex items-start space-x-3">
                      <Check className="w-5 h-5 text-emerald-400 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-300">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Right: Pricing */}
              <div className="text-center">
                <div className="bg-slate-900 rounded-2xl p-8 border border-slate-600">
                  <div className="mb-6">
                    <div className="text-5xl font-bold text-white mb-2">
                      $0
                    </div>
                    <div className="text-lg text-gray-400 mb-4">
                      primeros 7 días
                    </div>
                    <div className="text-sm text-gray-500">
                      Luego $97/mes o $997/año
                    </div>
                  </div>

                  <Button 
                    onClick={handleActivateClick}
                    size="lg" 
                    className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white font-semibold py-4 text-lg mb-4 group"
                  >
                    <Zap className="mr-2 group-hover:scale-110 transition-transform" />
                    Activar ahora gratis
                  </Button>
                  
                  <div className="text-xs text-gray-500">
                    Sin compromiso • Cancelás cuando quieras
                  </div>
                </div>

                {/* Urgency */}
                <div className="mt-6 p-4 bg-amber-500/10 border border-amber-500/20 rounded-lg">
                  <div className="text-amber-300 font-semibold mb-1">
                    🔥 Oferta limitada
                  </div>
                  <div className="text-sm text-amber-200">
                    Solo 30 activaciones gratuitas esta semana
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </div>

        {/* Guarantee */}
        <div className="text-center mt-12">
          <div className="inline-flex items-center space-x-2 bg-slate-800 px-6 py-3 rounded-full border border-slate-600">
            <Shield className="w-5 h-5 text-emerald-400" />
            <span className="text-gray-300">
              Garantía de 7 días sin riesgo • Resultados reales o te devolvemos todo
            </span>
          </div>
        </div>
      </div>
    </section>
  );
};

const Shield = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
  </svg>
);

export default Pricing;