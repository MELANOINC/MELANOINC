import Hero from "./Hero";
import Features from "./Features";
import LeadForm from "./LeadForm";
import Testimonials from "./Testimonials";
import Pricing from "./Pricing";
import Footer from "./Footer";

const LandingPage = () => {
  return (
    <div className="min-h-screen">
      <Hero />
      <Features />
      <LeadForm />
      <Testimonials />
      <Pricing />
      <Footer />
    </div>
  );
};

export default LandingPage;