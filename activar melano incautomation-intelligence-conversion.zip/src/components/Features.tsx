import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Bot, TrendingUp, Shield, Zap, DollarSign, Clock, ArrowRight } from "lucide-react";

const Features = () => {
  const handleLearnMoreClick = () => {
    const message = encodeURIComponent("Hola Melania! Quiero saber más sobre las funcionalidades de MELANO INC. ¿Me podés explicar cómo funcionan?");
    window.open(`https://wa.me/5492235506585?text=${message}`, '_blank');
  };

  const features = [
    {
      icon: Bot,
      title: "Bots de Inversión IA",
      description: "Scalping, arbitraje y detección de tendencias automatizadas 24/7",
      benefits: ["1-3% mensual", "Sin emociones", "Backtesting real"],
      color: "from-blue-500 to-cyan-500"
    },
    {
      icon: TrendingUp,
      title: "Ventas Automatizadas",
      description: "Leads, seguimiento y cierre para real estate y productos premium",
      benefits: ["30% más leads", "Cierre 24/7", "CRM integrado"],
      color: "from-emerald-500 to-teal-500"
    },
    {
      icon: Shield,
      title: "Gestión de Riesgo",
      description: "Stop loss inteligente y diversificación automática de portafolio",
      benefits: ["Riesgo controlado", "Diversificación", "Alertas tiempo real"],
      color: "from-amber-500 to-orange-500"
    },
    {
      icon: Zap,
      title: "IA que Aprende",
      description: "Machine learning que mejora con cada operación y interacción",
      benefits: ["Mejora continua", "Adaptación", "Optimización"],
      color: "from-purple-500 to-pink-500"
    },
    {
      icon: DollarSign,
      title: "ROI Transparente",
      description: "Dashboard en tiempo real con métricas detalladas de rendimiento",
      benefits: ["Métricas claras", "Reportes", "Transparencia total"],
      color: "from-green-500 to-emerald-500"
    },
    {
      icon: Clock,
      title: "Activación Inmediata",
      description: "Setup en minutos, no en semanas. Empezá a generar hoy mismo",
      benefits: ["Setup rápido", "Soporte 24/7", "Onboarding guiado"],
      color: "from-red-500 to-pink-500"
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
            La plataforma que
            <span className="bg-gradient-to-r from-teal-600 to-emerald-600 bg-clip-text text-transparent"> escala resultados</span>
          </h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto mb-8">
            No solo tecnología. Una arquitectura completa para automatizar ingresos 
            mientras te enfocás en lo que realmente importa.
          </p>
          <Button 
            onClick={handleLearnMoreClick}
            className="bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white group"
          >
            Conocé más detalles
            <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" />
          </Button>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const IconComponent = feature.icon;
            return (
              <Card key={index} className="p-6 hover:shadow-xl transition-all duration-300 border-0 bg-gradient-to-br from-slate-50 to-white group">
                <div className="mb-4">
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-r ${feature.color} p-3 mb-4 group-hover:scale-110 transition-transform`}>
                    <IconComponent className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-slate-600 mb-4">
                    {feature.description}
                  </p>
                </div>
                
                <div className="space-y-2">
                  {feature.benefits.map((benefit, benefitIndex) => (
                    <Badge 
                      key={benefitIndex} 
                      variant="secondary" 
                      className="mr-2 bg-slate-100 text-slate-700 hover:bg-slate-200"
                    >
                      {benefit}
                    </Badge>
                  ))}
                </div>
              </Card>
            );
          })}
        </div>

        {/* Stats Section */}
        <div className="mt-20 grid md:grid-cols-4 gap-8 text-center">
          <div>
            <div className="text-3xl md:text-4xl font-bold text-slate-900 mb-2">24/7</div>
            <div className="text-slate-600">Operación continua</div>
          </div>
          <div>
            <div className="text-3xl md:text-4xl font-bold text-slate-900 mb-2">1-3%</div>
            <div className="text-slate-600">Retorno mensual promedio</div>
          </div>
          <div>
            <div className="text-3xl md:text-4xl font-bold text-slate-900 mb-2">30+</div>
            <div className="text-slate-600">Estrategias disponibles</div>
          </div>
          <div>
            <div className="text-3xl md:text-4xl font-bold text-slate-900 mb-2">0</div>
            <div className="text-slate-600">Intervención manual</div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;