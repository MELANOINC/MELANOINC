import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Star, Quote, MessageCircle } from "lucide-react";

const Testimonials = () => {
  const handleContactClick = () => {
    const message = encodeURIComponent("Hola Melania! Vi los testimonios y quiero resultados como estos. ¿Podemos hablar?");
    window.open(`https://wa.me/5492235506585?text=${message}`, '_blank');
  };

  const testimonials = [
    {
      name: "Carlos Mendoza",
      role: "Inversor Real Estate",
      avatar: "CM",
      content: "En 3 meses, los bots de MELANO me generaron más que mi cartera tradicional en todo el año. Bruno no vende humo, entrega resultados.",
      rating: 5,
      result: "+127% ROI"
    },
    {
      name: "Ana Rodriguez",
      role: "Empresaria",
      avatar: "AR",
      content: "Melania automatizó completamente mi funnel de ventas. Ahora cierro deals mientras duermo. La inversión se pagó sola en 2 semanas.",
      rating: 5,
      result: "300% más leads"
    },
    {
      name: "Miguel Torres",
      role: "Trader",
      avatar: "MT",
      content: "Dejé de operar manualmente. Los bots de scalping son brutales, 2.3% mensual consistente sin estrés ni emociones.",
      rating: 5,
      result: "2.3% mensual"
    },
    {
      name: "Sofia Gutierrez",
      role: "Consultora",
      avatar: "SG",
      content: "La plataforma es otro nivel. No es solo tecnología, es una máquina de hacer dinero que funciona 24/7.",
      rating: 5,
      result: "$15K primer mes"
    }
  ];

  return (
    <section className="py-20 bg-slate-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
            Resultados
            <span className="bg-gradient-to-r from-teal-600 to-emerald-600 bg-clip-text text-transparent"> reales</span>
          </h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto mb-8">
            No prometemos. Entregamos. Estos son algunos de nuestros miembros que ya están generando ingresos automatizados.
          </p>
          <Button 
            onClick={handleContactClick}
            className="bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white"
          >
            <MessageCircle className="mr-2 w-4 h-4" />
            Quiero resultados así
          </Button>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="p-6 bg-white border-0 shadow-lg hover:shadow-xl transition-all duration-300 relative">
              <Quote className="absolute top-4 right-4 w-8 h-8 text-slate-200" />
              
              <div className="flex items-start space-x-4 mb-4">
                <Avatar className="w-12 h-12">
                  <AvatarFallback className="bg-gradient-to-r from-teal-500 to-emerald-500 text-white font-semibold">
                    {testimonial.avatar}
                  </AvatarFallback>
                </Avatar>
                
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <div>
                      <h4 className="font-semibold text-slate-900">{testimonial.name}</h4>
                      <p className="text-sm text-slate-600">{testimonial.role}</p>
                    </div>
                    <div className="flex items-center space-x-1">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
              
              <blockquote className="text-slate-700 mb-4 italic">
                "{testimonial.content}"
              </blockquote>
              
              <div className="flex justify-between items-center">
                <div className="bg-gradient-to-r from-emerald-500 to-teal-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
                  {testimonial.result}
                </div>
                <div className="text-xs text-slate-500">
                  Resultado verificado
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Trust indicators */}
        <div className="mt-16 text-center">
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="flex flex-col items-center">
              <div className="text-3xl font-bold text-slate-900 mb-2">500+</div>
              <div className="text-slate-600">Bots activos</div>
            </div>
            <div className="flex flex-col items-center">
              <div className="text-3xl font-bold text-slate-900 mb-2">$2.3M</div>
              <div className="text-slate-600">Gestionados</div>
            </div>
            <div className="flex flex-col items-center">
              <div className="text-3xl font-bold text-slate-900 mb-2">98%</div>
              <div className="text-slate-600">Satisfacción</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;