import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { MessageCircle, Sparkles } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const LeadForm = () => {
  const [formData, setFormData] = useState({
    name: "",
    whatsapp: "",
    interests: [] as string[]
  });
  const { toast } = useToast();

  const handleInterestChange = (interest: string, checked: boolean) => {
    if (checked) {
      setFormData(prev => ({
        ...prev,
        interests: [...prev.interests, interest]
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        interests: prev.interests.filter(i => i !== interest)
      }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.whatsapp) {
      toast({
        title: "Campos requeridos",
        description: "Por favor completá tu nombre y WhatsApp",
        variant: "destructive"
      });
      return;
    }
    
    // Create WhatsApp message with form data
    const interests = formData.interests.length > 0 ? formData.interests.join(", ") : "No especificado";
    const message = encodeURIComponent(
      `Hola Melania! Soy ${formData.name}. Quiero activar mi primer bot de MELANO INC.\n\nMi WhatsApp: ${formData.whatsapp}\nMe interesa: ${interests}\n\n¿Podemos hablar?`
    );
    
    // Open WhatsApp
    window.open(`https://wa.me/5492235506585?text=${message}`, '_blank');
    
    toast({
      title: "¡Perfecto!",
      description: "Te redirigimos a WhatsApp para hablar con Melania",
    });
    
    // Reset form
    setFormData({ name: "", whatsapp: "", interests: [] });
  };

  return (
    <section className="py-20 bg-slate-50">
      <div className="container mx-auto px-4">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
              Activá tu primer bot
              <span className="bg-gradient-to-r from-teal-600 to-emerald-600 bg-clip-text text-transparent"> gratis</span>
            </h2>
            <p className="text-lg text-slate-600">
              Completá el formulario y Melania te va a contactar para activar tu estrategia personalizada
            </p>
          </div>

          <Card className="p-8 shadow-xl border-0 bg-white">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-slate-700 font-medium">
                  Nombre completo
                </Label>
                <Input
                  id="name"
                  type="text"
                  placeholder="Tu nombre"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  className="h-12 text-lg"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="whatsapp" className="text-slate-700 font-medium">
                  WhatsApp
                </Label>
                <Input
                  id="whatsapp"
                  type="tel"
                  placeholder="+54 9 11 1234-5678"
                  value={formData.whatsapp}
                  onChange={(e) => setFormData(prev => ({ ...prev, whatsapp: e.target.value }))}
                  className="h-12 text-lg"
                  required
                />
              </div>

              <div className="space-y-4">
                <Label className="text-slate-700 font-medium">
                  ¿Qué te interesa?
                </Label>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <Checkbox
                      id="investment"
                      checked={formData.interests.includes("investment")}
                      onCheckedChange={(checked) => handleInterestChange("investment", checked as boolean)}
                    />
                    <Label htmlFor="investment" className="text-slate-600 cursor-pointer">
                      Inversión IA (Scalping, Arbitraje, Tendencias)
                    </Label>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Checkbox
                      id="sales"
                      checked={formData.interests.includes("sales")}
                      onCheckedChange={(checked) => handleInterestChange("sales", checked as boolean)}
                    />
                    <Label htmlFor="sales" className="text-slate-600 cursor-pointer">
                      Ventas automatizadas (Real Estate, High-ticket)
                    </Label>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Checkbox
                      id="both"
                      checked={formData.interests.includes("both")}
                      onCheckedChange={(checked) => handleInterestChange("both", checked as boolean)}
                    />
                    <Label htmlFor="both" className="text-slate-600 cursor-pointer">
                      Ambas (Inversión + Ventas)
                    </Label>
                  </div>
                </div>
              </div>

              <Button
                type="submit"
                size="lg"
                className="w-full bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white font-semibold py-4 text-lg group"
              >
                <MessageCircle className="mr-2" />
                Hablá con Melania
                <Sparkles className="ml-2 group-hover:rotate-12 transition-transform" />
              </Button>
            </form>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default LeadForm;